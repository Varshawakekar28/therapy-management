/*
 * Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
 *
 * Licensed under the Apache License, Version 2.0 (the "License"). You may not use this file except in compliance with
 * the License. A copy of the License is located at
 *
 * http://aws.amazon.com/apache2.0
 *
 * or in the "license" file accompanying this file. This file is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR
 * CONDITIONS OF ANY KIND, either express or implied. See the License for the specific language governing permissions
 * and limitations under the License.
 */
package com.amazonaws.services.s3.model;

public interface ExpectedBucketOwnerRequest {
    /**
     * Returns he account id of the expected bucket owner. If the bucket is owned by a different account, the request
     * will fail with an HTTP <code>403 (Access Denied)</code> error.
     */
    String getExpectedBucketOwner();

    /**
     * Set the account id of the expected bucket owner. If the bucket is owned by a different account, the request will
     * fail with an HTTP <code>403 (Access Denied)</code> error.
     */
    ExpectedBucketOwnerRequest withExpectedBucketOwner(String expectedBucketOwner);

    /**
     * Set the account id of the expected bucket owner. If the bucket is owned by a different account, the request will
     * fail with an HTTP <code>403 (Access Denied)</code> error.
     */
    void setExpectedBucketOwner(String expectedBucketOwner);
}
