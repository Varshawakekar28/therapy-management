/*
 * Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
 * 
 * Licensed under the Apache License, Version 2.0 (the "License"). You may not use this file except in compliance with
 * the License. A copy of the License is located at
 * 
 * http://aws.amazon.com/apache2.0
 * 
 * or in the "license" file accompanying this file. This file is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR
 * CONDITIONS OF ANY KIND, either express or implied. See the License for the specific language governing permissions
 * and limitations under the License.
 */

package software.amazon.awssdk.services.dynamodb;

import software.amazon.awssdk.annotations.Generated;
import software.amazon.awssdk.awscore.client.builder.AwsClientBuilder;
import software.amazon.awssdk.services.dynamodb.endpoints.DynamoDbEndpointProvider;

/**
 * This includes configuration specific to DynamoDB that is supported by both {@link DynamoDbClientBuilder} and
 * {@link DynamoDbAsyncClientBuilder}.
 */
@Generated("software.amazon.awssdk:codegen")
public interface DynamoDbBaseClientBuilder<B extends DynamoDbBaseClientBuilder<B, C>, C> extends AwsClientBuilder<B, C> {
    /**
     * @deprecated Use {@link #endpointDiscoveryEnabled(boolean)} instead.
     */
    @Deprecated
    B enableEndpointDiscovery();

    B endpointDiscoveryEnabled(boolean endpointDiscovery);

    /**
     * Set the {@link DynamoDbEndpointProvider} implementation that will be used by the client to determine the endpoint
     * for each request. This is optional; if none is provided a default implementation will be used the SDK.
     */
    default B endpointProvider(DynamoDbEndpointProvider endpointProvider) {
        throw new UnsupportedOperationException();
    }
}
