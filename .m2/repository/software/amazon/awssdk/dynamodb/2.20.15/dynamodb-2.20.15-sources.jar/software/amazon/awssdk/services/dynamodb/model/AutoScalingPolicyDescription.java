/*
 * Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
 * 
 * Licensed under the Apache License, Version 2.0 (the "License"). You may not use this file except in compliance with
 * the License. A copy of the License is located at
 * 
 * http://aws.amazon.com/apache2.0
 * 
 * or in the "license" file accompanying this file. This file is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR
 * CONDITIONS OF ANY KIND, either express or implied. See the License for the specific language governing permissions
 * and limitations under the License.
 */

package software.amazon.awssdk.services.dynamodb.model;

import java.io.Serializable;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.function.BiConsumer;
import java.util.function.Consumer;
import java.util.function.Function;
import software.amazon.awssdk.annotations.Generated;
import software.amazon.awssdk.core.SdkField;
import software.amazon.awssdk.core.SdkPojo;
import software.amazon.awssdk.core.protocol.MarshallLocation;
import software.amazon.awssdk.core.protocol.MarshallingType;
import software.amazon.awssdk.core.traits.LocationTrait;
import software.amazon.awssdk.utils.ToString;
import software.amazon.awssdk.utils.builder.CopyableBuilder;
import software.amazon.awssdk.utils.builder.ToCopyableBuilder;

/**
 * <p>
 * Represents the properties of the scaling policy.
 * </p>
 */
@Generated("software.amazon.awssdk:codegen")
public final class AutoScalingPolicyDescription implements SdkPojo, Serializable,
        ToCopyableBuilder<AutoScalingPolicyDescription.Builder, AutoScalingPolicyDescription> {
    private static final SdkField<String> POLICY_NAME_FIELD = SdkField.<String> builder(MarshallingType.STRING)
            .memberName("PolicyName").getter(getter(AutoScalingPolicyDescription::policyName))
            .setter(setter(Builder::policyName))
            .traits(LocationTrait.builder().location(MarshallLocation.PAYLOAD).locationName("PolicyName").build()).build();

    private static final SdkField<AutoScalingTargetTrackingScalingPolicyConfigurationDescription> TARGET_TRACKING_SCALING_POLICY_CONFIGURATION_FIELD = SdkField
            .<AutoScalingTargetTrackingScalingPolicyConfigurationDescription> builder(MarshallingType.SDK_POJO)
            .memberName("TargetTrackingScalingPolicyConfiguration")
            .getter(getter(AutoScalingPolicyDescription::targetTrackingScalingPolicyConfiguration))
            .setter(setter(Builder::targetTrackingScalingPolicyConfiguration))
            .constructor(AutoScalingTargetTrackingScalingPolicyConfigurationDescription::builder)
            .traits(LocationTrait.builder().location(MarshallLocation.PAYLOAD)
                    .locationName("TargetTrackingScalingPolicyConfiguration").build()).build();

    private static final List<SdkField<?>> SDK_FIELDS = Collections.unmodifiableList(Arrays.asList(POLICY_NAME_FIELD,
            TARGET_TRACKING_SCALING_POLICY_CONFIGURATION_FIELD));

    private static final long serialVersionUID = 1L;

    private final String policyName;

    private final AutoScalingTargetTrackingScalingPolicyConfigurationDescription targetTrackingScalingPolicyConfiguration;

    private AutoScalingPolicyDescription(BuilderImpl builder) {
        this.policyName = builder.policyName;
        this.targetTrackingScalingPolicyConfiguration = builder.targetTrackingScalingPolicyConfiguration;
    }

    /**
     * <p>
     * The name of the scaling policy.
     * </p>
     * 
     * @return The name of the scaling policy.
     */
    public final String policyName() {
        return policyName;
    }

    /**
     * <p>
     * Represents a target tracking scaling policy configuration.
     * </p>
     * 
     * @return Represents a target tracking scaling policy configuration.
     */
    public final AutoScalingTargetTrackingScalingPolicyConfigurationDescription targetTrackingScalingPolicyConfiguration() {
        return targetTrackingScalingPolicyConfiguration;
    }

    @Override
    public Builder toBuilder() {
        return new BuilderImpl(this);
    }

    public static Builder builder() {
        return new BuilderImpl();
    }

    public static Class<? extends Builder> serializableBuilderClass() {
        return BuilderImpl.class;
    }

    @Override
    public final int hashCode() {
        int hashCode = 1;
        hashCode = 31 * hashCode + Objects.hashCode(policyName());
        hashCode = 31 * hashCode + Objects.hashCode(targetTrackingScalingPolicyConfiguration());
        return hashCode;
    }

    @Override
    public final boolean equals(Object obj) {
        return equalsBySdkFields(obj);
    }

    @Override
    public final boolean equalsBySdkFields(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (!(obj instanceof AutoScalingPolicyDescription)) {
            return false;
        }
        AutoScalingPolicyDescription other = (AutoScalingPolicyDescription) obj;
        return Objects.equals(policyName(), other.policyName())
                && Objects.equals(targetTrackingScalingPolicyConfiguration(), other.targetTrackingScalingPolicyConfiguration());
    }

    /**
     * Returns a string representation of this object. This is useful for testing and debugging. Sensitive data will be
     * redacted from this string using a placeholder value.
     */
    @Override
    public final String toString() {
        return ToString.builder("AutoScalingPolicyDescription").add("PolicyName", policyName())
                .add("TargetTrackingScalingPolicyConfiguration", targetTrackingScalingPolicyConfiguration()).build();
    }

    public final <T> Optional<T> getValueForField(String fieldName, Class<T> clazz) {
        switch (fieldName) {
        case "PolicyName":
            return Optional.ofNullable(clazz.cast(policyName()));
        case "TargetTrackingScalingPolicyConfiguration":
            return Optional.ofNullable(clazz.cast(targetTrackingScalingPolicyConfiguration()));
        default:
            return Optional.empty();
        }
    }

    @Override
    public final List<SdkField<?>> sdkFields() {
        return SDK_FIELDS;
    }

    private static <T> Function<Object, T> getter(Function<AutoScalingPolicyDescription, T> g) {
        return obj -> g.apply((AutoScalingPolicyDescription) obj);
    }

    private static <T> BiConsumer<Object, T> setter(BiConsumer<Builder, T> s) {
        return (obj, val) -> s.accept((Builder) obj, val);
    }

    public interface Builder extends SdkPojo, CopyableBuilder<Builder, AutoScalingPolicyDescription> {
        /**
         * <p>
         * The name of the scaling policy.
         * </p>
         * 
         * @param policyName
         *        The name of the scaling policy.
         * @return Returns a reference to this object so that method calls can be chained together.
         */
        Builder policyName(String policyName);

        /**
         * <p>
         * Represents a target tracking scaling policy configuration.
         * </p>
         * 
         * @param targetTrackingScalingPolicyConfiguration
         *        Represents a target tracking scaling policy configuration.
         * @return Returns a reference to this object so that method calls can be chained together.
         */
        Builder targetTrackingScalingPolicyConfiguration(
                AutoScalingTargetTrackingScalingPolicyConfigurationDescription targetTrackingScalingPolicyConfiguration);

        /**
         * <p>
         * Represents a target tracking scaling policy configuration.
         * </p>
         * This is a convenience method that creates an instance of the
         * {@link AutoScalingTargetTrackingScalingPolicyConfigurationDescription.Builder} avoiding the need to create
         * one manually via {@link AutoScalingTargetTrackingScalingPolicyConfigurationDescription#builder()}.
         *
         * <p>
         * When the {@link Consumer} completes,
         * {@link AutoScalingTargetTrackingScalingPolicyConfigurationDescription.Builder#build()} is called immediately
         * and its result is passed to
         * {@link #targetTrackingScalingPolicyConfiguration(AutoScalingTargetTrackingScalingPolicyConfigurationDescription)}.
         * 
         * @param targetTrackingScalingPolicyConfiguration
         *        a consumer that will call methods on
         *        {@link AutoScalingTargetTrackingScalingPolicyConfigurationDescription.Builder}
         * @return Returns a reference to this object so that method calls can be chained together.
         * @see #targetTrackingScalingPolicyConfiguration(AutoScalingTargetTrackingScalingPolicyConfigurationDescription)
         */
        default Builder targetTrackingScalingPolicyConfiguration(
                Consumer<AutoScalingTargetTrackingScalingPolicyConfigurationDescription.Builder> targetTrackingScalingPolicyConfiguration) {
            return targetTrackingScalingPolicyConfiguration(AutoScalingTargetTrackingScalingPolicyConfigurationDescription
                    .builder().applyMutation(targetTrackingScalingPolicyConfiguration).build());
        }
    }

    static final class BuilderImpl implements Builder {
        private String policyName;

        private AutoScalingTargetTrackingScalingPolicyConfigurationDescription targetTrackingScalingPolicyConfiguration;

        private BuilderImpl() {
        }

        private BuilderImpl(AutoScalingPolicyDescription model) {
            policyName(model.policyName);
            targetTrackingScalingPolicyConfiguration(model.targetTrackingScalingPolicyConfiguration);
        }

        public final String getPolicyName() {
            return policyName;
        }

        public final void setPolicyName(String policyName) {
            this.policyName = policyName;
        }

        @Override
        public final Builder policyName(String policyName) {
            this.policyName = policyName;
            return this;
        }

        public final AutoScalingTargetTrackingScalingPolicyConfigurationDescription.Builder getTargetTrackingScalingPolicyConfiguration() {
            return targetTrackingScalingPolicyConfiguration != null ? targetTrackingScalingPolicyConfiguration.toBuilder() : null;
        }

        public final void setTargetTrackingScalingPolicyConfiguration(
                AutoScalingTargetTrackingScalingPolicyConfigurationDescription.BuilderImpl targetTrackingScalingPolicyConfiguration) {
            this.targetTrackingScalingPolicyConfiguration = targetTrackingScalingPolicyConfiguration != null ? targetTrackingScalingPolicyConfiguration
                    .build() : null;
        }

        @Override
        public final Builder targetTrackingScalingPolicyConfiguration(
                AutoScalingTargetTrackingScalingPolicyConfigurationDescription targetTrackingScalingPolicyConfiguration) {
            this.targetTrackingScalingPolicyConfiguration = targetTrackingScalingPolicyConfiguration;
            return this;
        }

        @Override
        public AutoScalingPolicyDescription build() {
            return new AutoScalingPolicyDescription(this);
        }

        @Override
        public List<SdkField<?>> sdkFields() {
            return SDK_FIELDS;
        }
    }
}
