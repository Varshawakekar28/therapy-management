/*
 * Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
 * 
 * Licensed under the Apache License, Version 2.0 (the "License"). You may not use this file except in compliance with
 * the License. A copy of the License is located at
 * 
 * http://aws.amazon.com/apache2.0
 * 
 * or in the "license" file accompanying this file. This file is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR
 * CONDITIONS OF ANY KIND, either express or implied. See the License for the specific language governing permissions
 * and limitations under the License.
 */

package software.amazon.awssdk.services.dynamodb.model;

import java.util.EnumSet;
import java.util.Map;
import java.util.Set;
import software.amazon.awssdk.annotations.Generated;
import software.amazon.awssdk.utils.internal.EnumUtils;

@Generated("software.amazon.awssdk:codegen")
public enum BatchStatementErrorCodeEnum {
    CONDITIONAL_CHECK_FAILED("ConditionalCheckFailed"),

    ITEM_COLLECTION_SIZE_LIMIT_EXCEEDED("ItemCollectionSizeLimitExceeded"),

    REQUEST_LIMIT_EXCEEDED("RequestLimitExceeded"),

    VALIDATION_ERROR("ValidationError"),

    PROVISIONED_THROUGHPUT_EXCEEDED("ProvisionedThroughputExceeded"),

    TRANSACTION_CONFLICT("TransactionConflict"),

    THROTTLING_ERROR("ThrottlingError"),

    INTERNAL_SERVER_ERROR("InternalServerError"),

    RESOURCE_NOT_FOUND("ResourceNotFound"),

    ACCESS_DENIED("AccessDenied"),

    DUPLICATE_ITEM("DuplicateItem"),

    UNKNOWN_TO_SDK_VERSION(null);

    private static final Map<String, BatchStatementErrorCodeEnum> VALUE_MAP = EnumUtils.uniqueIndex(
            BatchStatementErrorCodeEnum.class, BatchStatementErrorCodeEnum::toString);

    private final String value;

    private BatchStatementErrorCodeEnum(String value) {
        this.value = value;
    }

    @Override
    public String toString() {
        return String.valueOf(value);
    }

    /**
     * Use this in place of valueOf to convert the raw string returned by the service into the enum value.
     *
     * @param value
     *        real value
     * @return BatchStatementErrorCodeEnum corresponding to the value
     */
    public static BatchStatementErrorCodeEnum fromValue(String value) {
        if (value == null) {
            return null;
        }
        return VALUE_MAP.getOrDefault(value, UNKNOWN_TO_SDK_VERSION);
    }

    /**
     * Use this in place of {@link #values()} to return a {@link Set} of all values known to the SDK. This will return
     * all known enum values except {@link #UNKNOWN_TO_SDK_VERSION}.
     *
     * @return a {@link Set} of known {@link BatchStatementErrorCodeEnum}s
     */
    public static Set<BatchStatementErrorCodeEnum> knownValues() {
        Set<BatchStatementErrorCodeEnum> knownValues = EnumSet.allOf(BatchStatementErrorCodeEnum.class);
        knownValues.remove(UNKNOWN_TO_SDK_VERSION);
        return knownValues;
    }
}
