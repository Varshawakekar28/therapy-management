/*
 * Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
 * 
 * Licensed under the Apache License, Version 2.0 (the "License"). You may not use this file except in compliance with
 * the License. A copy of the License is located at
 * 
 * http://aws.amazon.com/apache2.0
 * 
 * or in the "license" file accompanying this file. This file is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR
 * CONDITIONS OF ANY KIND, either express or implied. See the License for the specific language governing permissions
 * and limitations under the License.
 */

package software.amazon.awssdk.services.dynamodb.model;

import java.util.EnumSet;
import java.util.Map;
import java.util.Set;
import software.amazon.awssdk.annotations.Generated;
import software.amazon.awssdk.utils.internal.EnumUtils;

@Generated("software.amazon.awssdk:codegen")
public enum ComparisonOperator {
    EQ("EQ"),

    NE("NE"),

    IN("IN"),

    LE("LE"),

    LT("LT"),

    GE("GE"),

    GT("GT"),

    BETWEEN("BETWEEN"),

    NOT_NULL("NOT_NULL"),

    NULL("NULL"),

    CONTAINS("CONTAINS"),

    NOT_CONTAINS("NOT_CONTAINS"),

    BEGINS_WITH("BEGINS_WITH"),

    UNKNOWN_TO_SDK_VERSION(null);

    private static final Map<String, ComparisonOperator> VALUE_MAP = EnumUtils.uniqueIndex(ComparisonOperator.class,
            ComparisonOperator::toString);

    private final String value;

    private ComparisonOperator(String value) {
        this.value = value;
    }

    @Override
    public String toString() {
        return String.valueOf(value);
    }

    /**
     * Use this in place of valueOf to convert the raw string returned by the service into the enum value.
     *
     * @param value
     *        real value
     * @return ComparisonOperator corresponding to the value
     */
    public static ComparisonOperator fromValue(String value) {
        if (value == null) {
            return null;
        }
        return VALUE_MAP.getOrDefault(value, UNKNOWN_TO_SDK_VERSION);
    }

    /**
     * Use this in place of {@link #values()} to return a {@link Set} of all values known to the SDK. This will return
     * all known enum values except {@link #UNKNOWN_TO_SDK_VERSION}.
     *
     * @return a {@link Set} of known {@link ComparisonOperator}s
     */
    public static Set<ComparisonOperator> knownValues() {
        Set<ComparisonOperator> knownValues = EnumSet.allOf(ComparisonOperator.class);
        knownValues.remove(UNKNOWN_TO_SDK_VERSION);
        return knownValues;
    }
}
