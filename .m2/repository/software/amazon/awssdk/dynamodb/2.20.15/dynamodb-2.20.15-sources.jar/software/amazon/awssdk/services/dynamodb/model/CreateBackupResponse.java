/*
 * Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
 * 
 * Licensed under the Apache License, Version 2.0 (the "License"). You may not use this file except in compliance with
 * the License. A copy of the License is located at
 * 
 * http://aws.amazon.com/apache2.0
 * 
 * or in the "license" file accompanying this file. This file is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR
 * CONDITIONS OF ANY KIND, either express or implied. See the License for the specific language governing permissions
 * and limitations under the License.
 */

package software.amazon.awssdk.services.dynamodb.model;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.function.BiConsumer;
import java.util.function.Consumer;
import java.util.function.Function;
import software.amazon.awssdk.annotations.Generated;
import software.amazon.awssdk.core.SdkField;
import software.amazon.awssdk.core.SdkPojo;
import software.amazon.awssdk.core.protocol.MarshallLocation;
import software.amazon.awssdk.core.protocol.MarshallingType;
import software.amazon.awssdk.core.traits.LocationTrait;
import software.amazon.awssdk.utils.ToString;
import software.amazon.awssdk.utils.builder.CopyableBuilder;
import software.amazon.awssdk.utils.builder.ToCopyableBuilder;

/**
 */
@Generated("software.amazon.awssdk:codegen")
public final class CreateBackupResponse extends DynamoDbResponse implements
        ToCopyableBuilder<CreateBackupResponse.Builder, CreateBackupResponse> {
    private static final SdkField<BackupDetails> BACKUP_DETAILS_FIELD = SdkField
            .<BackupDetails> builder(MarshallingType.SDK_POJO).memberName("BackupDetails")
            .getter(getter(CreateBackupResponse::backupDetails)).setter(setter(Builder::backupDetails))
            .constructor(BackupDetails::builder)
            .traits(LocationTrait.builder().location(MarshallLocation.PAYLOAD).locationName("BackupDetails").build()).build();

    private static final List<SdkField<?>> SDK_FIELDS = Collections.unmodifiableList(Arrays.asList(BACKUP_DETAILS_FIELD));

    private final BackupDetails backupDetails;

    private CreateBackupResponse(BuilderImpl builder) {
        super(builder);
        this.backupDetails = builder.backupDetails;
    }

    /**
     * <p>
     * Contains the details of the backup created for the table.
     * </p>
     * 
     * @return Contains the details of the backup created for the table.
     */
    public final BackupDetails backupDetails() {
        return backupDetails;
    }

    @Override
    public Builder toBuilder() {
        return new BuilderImpl(this);
    }

    public static Builder builder() {
        return new BuilderImpl();
    }

    public static Class<? extends Builder> serializableBuilderClass() {
        return BuilderImpl.class;
    }

    @Override
    public final int hashCode() {
        int hashCode = 1;
        hashCode = 31 * hashCode + super.hashCode();
        hashCode = 31 * hashCode + Objects.hashCode(backupDetails());
        return hashCode;
    }

    @Override
    public final boolean equals(Object obj) {
        return super.equals(obj) && equalsBySdkFields(obj);
    }

    @Override
    public final boolean equalsBySdkFields(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (!(obj instanceof CreateBackupResponse)) {
            return false;
        }
        CreateBackupResponse other = (CreateBackupResponse) obj;
        return Objects.equals(backupDetails(), other.backupDetails());
    }

    /**
     * Returns a string representation of this object. This is useful for testing and debugging. Sensitive data will be
     * redacted from this string using a placeholder value.
     */
    @Override
    public final String toString() {
        return ToString.builder("CreateBackupResponse").add("BackupDetails", backupDetails()).build();
    }

    public final <T> Optional<T> getValueForField(String fieldName, Class<T> clazz) {
        switch (fieldName) {
        case "BackupDetails":
            return Optional.ofNullable(clazz.cast(backupDetails()));
        default:
            return Optional.empty();
        }
    }

    @Override
    public final List<SdkField<?>> sdkFields() {
        return SDK_FIELDS;
    }

    private static <T> Function<Object, T> getter(Function<CreateBackupResponse, T> g) {
        return obj -> g.apply((CreateBackupResponse) obj);
    }

    private static <T> BiConsumer<Object, T> setter(BiConsumer<Builder, T> s) {
        return (obj, val) -> s.accept((Builder) obj, val);
    }

    public interface Builder extends DynamoDbResponse.Builder, SdkPojo, CopyableBuilder<Builder, CreateBackupResponse> {
        /**
         * <p>
         * Contains the details of the backup created for the table.
         * </p>
         * 
         * @param backupDetails
         *        Contains the details of the backup created for the table.
         * @return Returns a reference to this object so that method calls can be chained together.
         */
        Builder backupDetails(BackupDetails backupDetails);

        /**
         * <p>
         * Contains the details of the backup created for the table.
         * </p>
         * This is a convenience method that creates an instance of the {@link BackupDetails.Builder} avoiding the need
         * to create one manually via {@link BackupDetails#builder()}.
         *
         * <p>
         * When the {@link Consumer} completes, {@link BackupDetails.Builder#build()} is called immediately and its
         * result is passed to {@link #backupDetails(BackupDetails)}.
         * 
         * @param backupDetails
         *        a consumer that will call methods on {@link BackupDetails.Builder}
         * @return Returns a reference to this object so that method calls can be chained together.
         * @see #backupDetails(BackupDetails)
         */
        default Builder backupDetails(Consumer<BackupDetails.Builder> backupDetails) {
            return backupDetails(BackupDetails.builder().applyMutation(backupDetails).build());
        }
    }

    static final class BuilderImpl extends DynamoDbResponse.BuilderImpl implements Builder {
        private BackupDetails backupDetails;

        private BuilderImpl() {
        }

        private BuilderImpl(CreateBackupResponse model) {
            super(model);
            backupDetails(model.backupDetails);
        }

        public final BackupDetails.Builder getBackupDetails() {
            return backupDetails != null ? backupDetails.toBuilder() : null;
        }

        public final void setBackupDetails(BackupDetails.BuilderImpl backupDetails) {
            this.backupDetails = backupDetails != null ? backupDetails.build() : null;
        }

        @Override
        public final Builder backupDetails(BackupDetails backupDetails) {
            this.backupDetails = backupDetails;
            return this;
        }

        @Override
        public CreateBackupResponse build() {
            return new CreateBackupResponse(this);
        }

        @Override
        public List<SdkField<?>> sdkFields() {
            return SDK_FIELDS;
        }
    }
}
