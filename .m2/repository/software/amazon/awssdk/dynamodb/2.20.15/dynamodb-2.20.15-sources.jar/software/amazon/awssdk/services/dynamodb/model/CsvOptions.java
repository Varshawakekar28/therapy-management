/*
 * Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
 * 
 * Licensed under the Apache License, Version 2.0 (the "License"). You may not use this file except in compliance with
 * the License. A copy of the License is located at
 * 
 * http://aws.amazon.com/apache2.0
 * 
 * or in the "license" file accompanying this file. This file is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR
 * CONDITIONS OF ANY KIND, either express or implied. See the License for the specific language governing permissions
 * and limitations under the License.
 */

package software.amazon.awssdk.services.dynamodb.model;

import java.io.Serializable;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.function.BiConsumer;
import java.util.function.Function;
import software.amazon.awssdk.annotations.Generated;
import software.amazon.awssdk.core.SdkField;
import software.amazon.awssdk.core.SdkPojo;
import software.amazon.awssdk.core.protocol.MarshallLocation;
import software.amazon.awssdk.core.protocol.MarshallingType;
import software.amazon.awssdk.core.traits.ListTrait;
import software.amazon.awssdk.core.traits.LocationTrait;
import software.amazon.awssdk.core.util.DefaultSdkAutoConstructList;
import software.amazon.awssdk.core.util.SdkAutoConstructList;
import software.amazon.awssdk.utils.ToString;
import software.amazon.awssdk.utils.builder.CopyableBuilder;
import software.amazon.awssdk.utils.builder.ToCopyableBuilder;

/**
 * <p>
 * Processing options for the CSV file being imported.
 * </p>
 */
@Generated("software.amazon.awssdk:codegen")
public final class CsvOptions implements SdkPojo, Serializable, ToCopyableBuilder<CsvOptions.Builder, CsvOptions> {
    private static final SdkField<String> DELIMITER_FIELD = SdkField.<String> builder(MarshallingType.STRING)
            .memberName("Delimiter").getter(getter(CsvOptions::delimiter)).setter(setter(Builder::delimiter))
            .traits(LocationTrait.builder().location(MarshallLocation.PAYLOAD).locationName("Delimiter").build()).build();

    private static final SdkField<List<String>> HEADER_LIST_FIELD = SdkField
            .<List<String>> builder(MarshallingType.LIST)
            .memberName("HeaderList")
            .getter(getter(CsvOptions::headerList))
            .setter(setter(Builder::headerList))
            .traits(LocationTrait.builder().location(MarshallLocation.PAYLOAD).locationName("HeaderList").build(),
                    ListTrait
                            .builder()
                            .memberLocationName(null)
                            .memberFieldInfo(
                                    SdkField.<String> builder(MarshallingType.STRING)
                                            .traits(LocationTrait.builder().location(MarshallLocation.PAYLOAD)
                                                    .locationName("member").build()).build()).build()).build();

    private static final List<SdkField<?>> SDK_FIELDS = Collections.unmodifiableList(Arrays.asList(DELIMITER_FIELD,
            HEADER_LIST_FIELD));

    private static final long serialVersionUID = 1L;

    private final String delimiter;

    private final List<String> headerList;

    private CsvOptions(BuilderImpl builder) {
        this.delimiter = builder.delimiter;
        this.headerList = builder.headerList;
    }

    /**
     * <p>
     * The delimiter used for separating items in the CSV file being imported.
     * </p>
     * 
     * @return The delimiter used for separating items in the CSV file being imported.
     */
    public final String delimiter() {
        return delimiter;
    }

    /**
     * For responses, this returns true if the service returned a value for the HeaderList property. This DOES NOT check
     * that the value is non-empty (for which, you should check the {@code isEmpty()} method on the property). This is
     * useful because the SDK will never return a null collection or map, but you may need to differentiate between the
     * service returning nothing (or null) and the service returning an empty collection or map. For requests, this
     * returns true if a value for the property was specified in the request builder, and false if a value was not
     * specified.
     */
    public final boolean hasHeaderList() {
        return headerList != null && !(headerList instanceof SdkAutoConstructList);
    }

    /**
     * <p>
     * List of the headers used to specify a common header for all source CSV files being imported. If this field is
     * specified then the first line of each CSV file is treated as data instead of the header. If this field is not
     * specified the the first line of each CSV file is treated as the header.
     * </p>
     * <p>
     * Attempts to modify the collection returned by this method will result in an UnsupportedOperationException.
     * </p>
     * <p>
     * This method will never return null. If you would like to know whether the service returned this field (so that
     * you can differentiate between null and empty), you can use the {@link #hasHeaderList} method.
     * </p>
     * 
     * @return List of the headers used to specify a common header for all source CSV files being imported. If this
     *         field is specified then the first line of each CSV file is treated as data instead of the header. If this
     *         field is not specified the the first line of each CSV file is treated as the header.
     */
    public final List<String> headerList() {
        return headerList;
    }

    @Override
    public Builder toBuilder() {
        return new BuilderImpl(this);
    }

    public static Builder builder() {
        return new BuilderImpl();
    }

    public static Class<? extends Builder> serializableBuilderClass() {
        return BuilderImpl.class;
    }

    @Override
    public final int hashCode() {
        int hashCode = 1;
        hashCode = 31 * hashCode + Objects.hashCode(delimiter());
        hashCode = 31 * hashCode + Objects.hashCode(hasHeaderList() ? headerList() : null);
        return hashCode;
    }

    @Override
    public final boolean equals(Object obj) {
        return equalsBySdkFields(obj);
    }

    @Override
    public final boolean equalsBySdkFields(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (!(obj instanceof CsvOptions)) {
            return false;
        }
        CsvOptions other = (CsvOptions) obj;
        return Objects.equals(delimiter(), other.delimiter()) && hasHeaderList() == other.hasHeaderList()
                && Objects.equals(headerList(), other.headerList());
    }

    /**
     * Returns a string representation of this object. This is useful for testing and debugging. Sensitive data will be
     * redacted from this string using a placeholder value.
     */
    @Override
    public final String toString() {
        return ToString.builder("CsvOptions").add("Delimiter", delimiter())
                .add("HeaderList", hasHeaderList() ? headerList() : null).build();
    }

    public final <T> Optional<T> getValueForField(String fieldName, Class<T> clazz) {
        switch (fieldName) {
        case "Delimiter":
            return Optional.ofNullable(clazz.cast(delimiter()));
        case "HeaderList":
            return Optional.ofNullable(clazz.cast(headerList()));
        default:
            return Optional.empty();
        }
    }

    @Override
    public final List<SdkField<?>> sdkFields() {
        return SDK_FIELDS;
    }

    private static <T> Function<Object, T> getter(Function<CsvOptions, T> g) {
        return obj -> g.apply((CsvOptions) obj);
    }

    private static <T> BiConsumer<Object, T> setter(BiConsumer<Builder, T> s) {
        return (obj, val) -> s.accept((Builder) obj, val);
    }

    public interface Builder extends SdkPojo, CopyableBuilder<Builder, CsvOptions> {
        /**
         * <p>
         * The delimiter used for separating items in the CSV file being imported.
         * </p>
         * 
         * @param delimiter
         *        The delimiter used for separating items in the CSV file being imported.
         * @return Returns a reference to this object so that method calls can be chained together.
         */
        Builder delimiter(String delimiter);

        /**
         * <p>
         * List of the headers used to specify a common header for all source CSV files being imported. If this field is
         * specified then the first line of each CSV file is treated as data instead of the header. If this field is not
         * specified the the first line of each CSV file is treated as the header.
         * </p>
         * 
         * @param headerList
         *        List of the headers used to specify a common header for all source CSV files being imported. If this
         *        field is specified then the first line of each CSV file is treated as data instead of the header. If
         *        this field is not specified the the first line of each CSV file is treated as the header.
         * @return Returns a reference to this object so that method calls can be chained together.
         */
        Builder headerList(Collection<String> headerList);

        /**
         * <p>
         * List of the headers used to specify a common header for all source CSV files being imported. If this field is
         * specified then the first line of each CSV file is treated as data instead of the header. If this field is not
         * specified the the first line of each CSV file is treated as the header.
         * </p>
         * 
         * @param headerList
         *        List of the headers used to specify a common header for all source CSV files being imported. If this
         *        field is specified then the first line of each CSV file is treated as data instead of the header. If
         *        this field is not specified the the first line of each CSV file is treated as the header.
         * @return Returns a reference to this object so that method calls can be chained together.
         */
        Builder headerList(String... headerList);
    }

    static final class BuilderImpl implements Builder {
        private String delimiter;

        private List<String> headerList = DefaultSdkAutoConstructList.getInstance();

        private BuilderImpl() {
        }

        private BuilderImpl(CsvOptions model) {
            delimiter(model.delimiter);
            headerList(model.headerList);
        }

        public final String getDelimiter() {
            return delimiter;
        }

        public final void setDelimiter(String delimiter) {
            this.delimiter = delimiter;
        }

        @Override
        public final Builder delimiter(String delimiter) {
            this.delimiter = delimiter;
            return this;
        }

        public final Collection<String> getHeaderList() {
            if (headerList instanceof SdkAutoConstructList) {
                return null;
            }
            return headerList;
        }

        public final void setHeaderList(Collection<String> headerList) {
            this.headerList = CsvHeaderListCopier.copy(headerList);
        }

        @Override
        public final Builder headerList(Collection<String> headerList) {
            this.headerList = CsvHeaderListCopier.copy(headerList);
            return this;
        }

        @Override
        @SafeVarargs
        public final Builder headerList(String... headerList) {
            headerList(Arrays.asList(headerList));
            return this;
        }

        @Override
        public CsvOptions build() {
            return new CsvOptions(this);
        }

        @Override
        public List<SdkField<?>> sdkFields() {
            return SDK_FIELDS;
        }
    }
}
