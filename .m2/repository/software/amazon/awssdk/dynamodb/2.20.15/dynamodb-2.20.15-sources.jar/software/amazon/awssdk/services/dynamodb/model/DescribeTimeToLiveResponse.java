/*
 * Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
 * 
 * Licensed under the Apache License, Version 2.0 (the "License"). You may not use this file except in compliance with
 * the License. A copy of the License is located at
 * 
 * http://aws.amazon.com/apache2.0
 * 
 * or in the "license" file accompanying this file. This file is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR
 * CONDITIONS OF ANY KIND, either express or implied. See the License for the specific language governing permissions
 * and limitations under the License.
 */

package software.amazon.awssdk.services.dynamodb.model;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.function.BiConsumer;
import java.util.function.Consumer;
import java.util.function.Function;
import software.amazon.awssdk.annotations.Generated;
import software.amazon.awssdk.core.SdkField;
import software.amazon.awssdk.core.SdkPojo;
import software.amazon.awssdk.core.protocol.MarshallLocation;
import software.amazon.awssdk.core.protocol.MarshallingType;
import software.amazon.awssdk.core.traits.LocationTrait;
import software.amazon.awssdk.utils.ToString;
import software.amazon.awssdk.utils.builder.CopyableBuilder;
import software.amazon.awssdk.utils.builder.ToCopyableBuilder;

/**
 */
@Generated("software.amazon.awssdk:codegen")
public final class DescribeTimeToLiveResponse extends DynamoDbResponse implements
        ToCopyableBuilder<DescribeTimeToLiveResponse.Builder, DescribeTimeToLiveResponse> {
    private static final SdkField<TimeToLiveDescription> TIME_TO_LIVE_DESCRIPTION_FIELD = SdkField
            .<TimeToLiveDescription> builder(MarshallingType.SDK_POJO).memberName("TimeToLiveDescription")
            .getter(getter(DescribeTimeToLiveResponse::timeToLiveDescription)).setter(setter(Builder::timeToLiveDescription))
            .constructor(TimeToLiveDescription::builder)
            .traits(LocationTrait.builder().location(MarshallLocation.PAYLOAD).locationName("TimeToLiveDescription").build())
            .build();

    private static final List<SdkField<?>> SDK_FIELDS = Collections.unmodifiableList(Arrays
            .asList(TIME_TO_LIVE_DESCRIPTION_FIELD));

    private final TimeToLiveDescription timeToLiveDescription;

    private DescribeTimeToLiveResponse(BuilderImpl builder) {
        super(builder);
        this.timeToLiveDescription = builder.timeToLiveDescription;
    }

    /**
     * <p/>
     * 
     * @return
     */
    public final TimeToLiveDescription timeToLiveDescription() {
        return timeToLiveDescription;
    }

    @Override
    public Builder toBuilder() {
        return new BuilderImpl(this);
    }

    public static Builder builder() {
        return new BuilderImpl();
    }

    public static Class<? extends Builder> serializableBuilderClass() {
        return BuilderImpl.class;
    }

    @Override
    public final int hashCode() {
        int hashCode = 1;
        hashCode = 31 * hashCode + super.hashCode();
        hashCode = 31 * hashCode + Objects.hashCode(timeToLiveDescription());
        return hashCode;
    }

    @Override
    public final boolean equals(Object obj) {
        return super.equals(obj) && equalsBySdkFields(obj);
    }

    @Override
    public final boolean equalsBySdkFields(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (!(obj instanceof DescribeTimeToLiveResponse)) {
            return false;
        }
        DescribeTimeToLiveResponse other = (DescribeTimeToLiveResponse) obj;
        return Objects.equals(timeToLiveDescription(), other.timeToLiveDescription());
    }

    /**
     * Returns a string representation of this object. This is useful for testing and debugging. Sensitive data will be
     * redacted from this string using a placeholder value.
     */
    @Override
    public final String toString() {
        return ToString.builder("DescribeTimeToLiveResponse").add("TimeToLiveDescription", timeToLiveDescription()).build();
    }

    public final <T> Optional<T> getValueForField(String fieldName, Class<T> clazz) {
        switch (fieldName) {
        case "TimeToLiveDescription":
            return Optional.ofNullable(clazz.cast(timeToLiveDescription()));
        default:
            return Optional.empty();
        }
    }

    @Override
    public final List<SdkField<?>> sdkFields() {
        return SDK_FIELDS;
    }

    private static <T> Function<Object, T> getter(Function<DescribeTimeToLiveResponse, T> g) {
        return obj -> g.apply((DescribeTimeToLiveResponse) obj);
    }

    private static <T> BiConsumer<Object, T> setter(BiConsumer<Builder, T> s) {
        return (obj, val) -> s.accept((Builder) obj, val);
    }

    public interface Builder extends DynamoDbResponse.Builder, SdkPojo, CopyableBuilder<Builder, DescribeTimeToLiveResponse> {
        /**
         * <p/>
         * 
         * @param timeToLiveDescription
         * @return Returns a reference to this object so that method calls can be chained together.
         */
        Builder timeToLiveDescription(TimeToLiveDescription timeToLiveDescription);

        /**
         * <p/>
         * This is a convenience method that creates an instance of the {@link TimeToLiveDescription.Builder} avoiding
         * the need to create one manually via {@link TimeToLiveDescription#builder()}.
         *
         * <p>
         * When the {@link Consumer} completes, {@link TimeToLiveDescription.Builder#build()} is called immediately and
         * its result is passed to {@link #timeToLiveDescription(TimeToLiveDescription)}.
         * 
         * @param timeToLiveDescription
         *        a consumer that will call methods on {@link TimeToLiveDescription.Builder}
         * @return Returns a reference to this object so that method calls can be chained together.
         * @see #timeToLiveDescription(TimeToLiveDescription)
         */
        default Builder timeToLiveDescription(Consumer<TimeToLiveDescription.Builder> timeToLiveDescription) {
            return timeToLiveDescription(TimeToLiveDescription.builder().applyMutation(timeToLiveDescription).build());
        }
    }

    static final class BuilderImpl extends DynamoDbResponse.BuilderImpl implements Builder {
        private TimeToLiveDescription timeToLiveDescription;

        private BuilderImpl() {
        }

        private BuilderImpl(DescribeTimeToLiveResponse model) {
            super(model);
            timeToLiveDescription(model.timeToLiveDescription);
        }

        public final TimeToLiveDescription.Builder getTimeToLiveDescription() {
            return timeToLiveDescription != null ? timeToLiveDescription.toBuilder() : null;
        }

        public final void setTimeToLiveDescription(TimeToLiveDescription.BuilderImpl timeToLiveDescription) {
            this.timeToLiveDescription = timeToLiveDescription != null ? timeToLiveDescription.build() : null;
        }

        @Override
        public final Builder timeToLiveDescription(TimeToLiveDescription timeToLiveDescription) {
            this.timeToLiveDescription = timeToLiveDescription;
            return this;
        }

        @Override
        public DescribeTimeToLiveResponse build() {
            return new DescribeTimeToLiveResponse(this);
        }

        @Override
        public List<SdkField<?>> sdkFields() {
            return SDK_FIELDS;
        }
    }
}
