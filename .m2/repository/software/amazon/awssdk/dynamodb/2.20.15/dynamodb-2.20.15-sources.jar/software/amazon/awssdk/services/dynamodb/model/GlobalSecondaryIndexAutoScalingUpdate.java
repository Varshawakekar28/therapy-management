/*
 * Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
 * 
 * Licensed under the Apache License, Version 2.0 (the "License"). You may not use this file except in compliance with
 * the License. A copy of the License is located at
 * 
 * http://aws.amazon.com/apache2.0
 * 
 * or in the "license" file accompanying this file. This file is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR
 * CONDITIONS OF ANY KIND, either express or implied. See the License for the specific language governing permissions
 * and limitations under the License.
 */

package software.amazon.awssdk.services.dynamodb.model;

import java.io.Serializable;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.function.BiConsumer;
import java.util.function.Consumer;
import java.util.function.Function;
import software.amazon.awssdk.annotations.Generated;
import software.amazon.awssdk.core.SdkField;
import software.amazon.awssdk.core.SdkPojo;
import software.amazon.awssdk.core.protocol.MarshallLocation;
import software.amazon.awssdk.core.protocol.MarshallingType;
import software.amazon.awssdk.core.traits.LocationTrait;
import software.amazon.awssdk.utils.ToString;
import software.amazon.awssdk.utils.builder.CopyableBuilder;
import software.amazon.awssdk.utils.builder.ToCopyableBuilder;

/**
 * <p>
 * Represents the auto scaling settings of a global secondary index for a global table that will be modified.
 * </p>
 */
@Generated("software.amazon.awssdk:codegen")
public final class GlobalSecondaryIndexAutoScalingUpdate implements SdkPojo, Serializable,
        ToCopyableBuilder<GlobalSecondaryIndexAutoScalingUpdate.Builder, GlobalSecondaryIndexAutoScalingUpdate> {
    private static final SdkField<String> INDEX_NAME_FIELD = SdkField.<String> builder(MarshallingType.STRING)
            .memberName("IndexName").getter(getter(GlobalSecondaryIndexAutoScalingUpdate::indexName))
            .setter(setter(Builder::indexName))
            .traits(LocationTrait.builder().location(MarshallLocation.PAYLOAD).locationName("IndexName").build()).build();

    private static final SdkField<AutoScalingSettingsUpdate> PROVISIONED_WRITE_CAPACITY_AUTO_SCALING_UPDATE_FIELD = SdkField
            .<AutoScalingSettingsUpdate> builder(MarshallingType.SDK_POJO)
            .memberName("ProvisionedWriteCapacityAutoScalingUpdate")
            .getter(getter(GlobalSecondaryIndexAutoScalingUpdate::provisionedWriteCapacityAutoScalingUpdate))
            .setter(setter(Builder::provisionedWriteCapacityAutoScalingUpdate))
            .constructor(AutoScalingSettingsUpdate::builder)
            .traits(LocationTrait.builder().location(MarshallLocation.PAYLOAD)
                    .locationName("ProvisionedWriteCapacityAutoScalingUpdate").build()).build();

    private static final List<SdkField<?>> SDK_FIELDS = Collections.unmodifiableList(Arrays.asList(INDEX_NAME_FIELD,
            PROVISIONED_WRITE_CAPACITY_AUTO_SCALING_UPDATE_FIELD));

    private static final long serialVersionUID = 1L;

    private final String indexName;

    private final AutoScalingSettingsUpdate provisionedWriteCapacityAutoScalingUpdate;

    private GlobalSecondaryIndexAutoScalingUpdate(BuilderImpl builder) {
        this.indexName = builder.indexName;
        this.provisionedWriteCapacityAutoScalingUpdate = builder.provisionedWriteCapacityAutoScalingUpdate;
    }

    /**
     * <p>
     * The name of the global secondary index.
     * </p>
     * 
     * @return The name of the global secondary index.
     */
    public final String indexName() {
        return indexName;
    }

    /**
     * Returns the value of the ProvisionedWriteCapacityAutoScalingUpdate property for this object.
     * 
     * @return The value of the ProvisionedWriteCapacityAutoScalingUpdate property for this object.
     */
    public final AutoScalingSettingsUpdate provisionedWriteCapacityAutoScalingUpdate() {
        return provisionedWriteCapacityAutoScalingUpdate;
    }

    @Override
    public Builder toBuilder() {
        return new BuilderImpl(this);
    }

    public static Builder builder() {
        return new BuilderImpl();
    }

    public static Class<? extends Builder> serializableBuilderClass() {
        return BuilderImpl.class;
    }

    @Override
    public final int hashCode() {
        int hashCode = 1;
        hashCode = 31 * hashCode + Objects.hashCode(indexName());
        hashCode = 31 * hashCode + Objects.hashCode(provisionedWriteCapacityAutoScalingUpdate());
        return hashCode;
    }

    @Override
    public final boolean equals(Object obj) {
        return equalsBySdkFields(obj);
    }

    @Override
    public final boolean equalsBySdkFields(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (!(obj instanceof GlobalSecondaryIndexAutoScalingUpdate)) {
            return false;
        }
        GlobalSecondaryIndexAutoScalingUpdate other = (GlobalSecondaryIndexAutoScalingUpdate) obj;
        return Objects.equals(indexName(), other.indexName())
                && Objects.equals(provisionedWriteCapacityAutoScalingUpdate(), other.provisionedWriteCapacityAutoScalingUpdate());
    }

    /**
     * Returns a string representation of this object. This is useful for testing and debugging. Sensitive data will be
     * redacted from this string using a placeholder value.
     */
    @Override
    public final String toString() {
        return ToString.builder("GlobalSecondaryIndexAutoScalingUpdate").add("IndexName", indexName())
                .add("ProvisionedWriteCapacityAutoScalingUpdate", provisionedWriteCapacityAutoScalingUpdate()).build();
    }

    public final <T> Optional<T> getValueForField(String fieldName, Class<T> clazz) {
        switch (fieldName) {
        case "IndexName":
            return Optional.ofNullable(clazz.cast(indexName()));
        case "ProvisionedWriteCapacityAutoScalingUpdate":
            return Optional.ofNullable(clazz.cast(provisionedWriteCapacityAutoScalingUpdate()));
        default:
            return Optional.empty();
        }
    }

    @Override
    public final List<SdkField<?>> sdkFields() {
        return SDK_FIELDS;
    }

    private static <T> Function<Object, T> getter(Function<GlobalSecondaryIndexAutoScalingUpdate, T> g) {
        return obj -> g.apply((GlobalSecondaryIndexAutoScalingUpdate) obj);
    }

    private static <T> BiConsumer<Object, T> setter(BiConsumer<Builder, T> s) {
        return (obj, val) -> s.accept((Builder) obj, val);
    }

    public interface Builder extends SdkPojo, CopyableBuilder<Builder, GlobalSecondaryIndexAutoScalingUpdate> {
        /**
         * <p>
         * The name of the global secondary index.
         * </p>
         * 
         * @param indexName
         *        The name of the global secondary index.
         * @return Returns a reference to this object so that method calls can be chained together.
         */
        Builder indexName(String indexName);

        /**
         * Sets the value of the ProvisionedWriteCapacityAutoScalingUpdate property for this object.
         *
         * @param provisionedWriteCapacityAutoScalingUpdate
         *        The new value for the ProvisionedWriteCapacityAutoScalingUpdate property for this object.
         * @return Returns a reference to this object so that method calls can be chained together.
         */
        Builder provisionedWriteCapacityAutoScalingUpdate(AutoScalingSettingsUpdate provisionedWriteCapacityAutoScalingUpdate);

        /**
         * Sets the value of the ProvisionedWriteCapacityAutoScalingUpdate property for this object.
         *
         * This is a convenience method that creates an instance of the {@link AutoScalingSettingsUpdate.Builder}
         * avoiding the need to create one manually via {@link AutoScalingSettingsUpdate#builder()}.
         *
         * <p>
         * When the {@link Consumer} completes, {@link AutoScalingSettingsUpdate.Builder#build()} is called immediately
         * and its result is passed to {@link #provisionedWriteCapacityAutoScalingUpdate(AutoScalingSettingsUpdate)}.
         * 
         * @param provisionedWriteCapacityAutoScalingUpdate
         *        a consumer that will call methods on {@link AutoScalingSettingsUpdate.Builder}
         * @return Returns a reference to this object so that method calls can be chained together.
         * @see #provisionedWriteCapacityAutoScalingUpdate(AutoScalingSettingsUpdate)
         */
        default Builder provisionedWriteCapacityAutoScalingUpdate(
                Consumer<AutoScalingSettingsUpdate.Builder> provisionedWriteCapacityAutoScalingUpdate) {
            return provisionedWriteCapacityAutoScalingUpdate(AutoScalingSettingsUpdate.builder()
                    .applyMutation(provisionedWriteCapacityAutoScalingUpdate).build());
        }
    }

    static final class BuilderImpl implements Builder {
        private String indexName;

        private AutoScalingSettingsUpdate provisionedWriteCapacityAutoScalingUpdate;

        private BuilderImpl() {
        }

        private BuilderImpl(GlobalSecondaryIndexAutoScalingUpdate model) {
            indexName(model.indexName);
            provisionedWriteCapacityAutoScalingUpdate(model.provisionedWriteCapacityAutoScalingUpdate);
        }

        public final String getIndexName() {
            return indexName;
        }

        public final void setIndexName(String indexName) {
            this.indexName = indexName;
        }

        @Override
        public final Builder indexName(String indexName) {
            this.indexName = indexName;
            return this;
        }

        public final AutoScalingSettingsUpdate.Builder getProvisionedWriteCapacityAutoScalingUpdate() {
            return provisionedWriteCapacityAutoScalingUpdate != null ? provisionedWriteCapacityAutoScalingUpdate.toBuilder()
                    : null;
        }

        public final void setProvisionedWriteCapacityAutoScalingUpdate(
                AutoScalingSettingsUpdate.BuilderImpl provisionedWriteCapacityAutoScalingUpdate) {
            this.provisionedWriteCapacityAutoScalingUpdate = provisionedWriteCapacityAutoScalingUpdate != null ? provisionedWriteCapacityAutoScalingUpdate
                    .build() : null;
        }

        @Override
        public final Builder provisionedWriteCapacityAutoScalingUpdate(
                AutoScalingSettingsUpdate provisionedWriteCapacityAutoScalingUpdate) {
            this.provisionedWriteCapacityAutoScalingUpdate = provisionedWriteCapacityAutoScalingUpdate;
            return this;
        }

        @Override
        public GlobalSecondaryIndexAutoScalingUpdate build() {
            return new GlobalSecondaryIndexAutoScalingUpdate(this);
        }

        @Override
        public List<SdkField<?>> sdkFields() {
            return SDK_FIELDS;
        }
    }
}
