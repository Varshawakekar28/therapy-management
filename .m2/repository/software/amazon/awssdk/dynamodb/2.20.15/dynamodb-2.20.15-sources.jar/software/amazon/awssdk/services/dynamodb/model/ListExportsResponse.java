/*
 * Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
 * 
 * Licensed under the Apache License, Version 2.0 (the "License"). You may not use this file except in compliance with
 * the License. A copy of the License is located at
 * 
 * http://aws.amazon.com/apache2.0
 * 
 * or in the "license" file accompanying this file. This file is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR
 * CONDITIONS OF ANY KIND, either express or implied. See the License for the specific language governing permissions
 * and limitations under the License.
 */

package software.amazon.awssdk.services.dynamodb.model;

import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.function.BiConsumer;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.stream.Collectors;
import java.util.stream.Stream;
import software.amazon.awssdk.annotations.Generated;
import software.amazon.awssdk.core.SdkField;
import software.amazon.awssdk.core.SdkPojo;
import software.amazon.awssdk.core.protocol.MarshallLocation;
import software.amazon.awssdk.core.protocol.MarshallingType;
import software.amazon.awssdk.core.traits.ListTrait;
import software.amazon.awssdk.core.traits.LocationTrait;
import software.amazon.awssdk.core.util.DefaultSdkAutoConstructList;
import software.amazon.awssdk.core.util.SdkAutoConstructList;
import software.amazon.awssdk.utils.ToString;
import software.amazon.awssdk.utils.builder.CopyableBuilder;
import software.amazon.awssdk.utils.builder.ToCopyableBuilder;

/**
 */
@Generated("software.amazon.awssdk:codegen")
public final class ListExportsResponse extends DynamoDbResponse implements
        ToCopyableBuilder<ListExportsResponse.Builder, ListExportsResponse> {
    private static final SdkField<List<ExportSummary>> EXPORT_SUMMARIES_FIELD = SdkField
            .<List<ExportSummary>> builder(MarshallingType.LIST)
            .memberName("ExportSummaries")
            .getter(getter(ListExportsResponse::exportSummaries))
            .setter(setter(Builder::exportSummaries))
            .traits(LocationTrait.builder().location(MarshallLocation.PAYLOAD).locationName("ExportSummaries").build(),
                    ListTrait
                            .builder()
                            .memberLocationName(null)
                            .memberFieldInfo(
                                    SdkField.<ExportSummary> builder(MarshallingType.SDK_POJO)
                                            .constructor(ExportSummary::builder)
                                            .traits(LocationTrait.builder().location(MarshallLocation.PAYLOAD)
                                                    .locationName("member").build()).build()).build()).build();

    private static final SdkField<String> NEXT_TOKEN_FIELD = SdkField.<String> builder(MarshallingType.STRING)
            .memberName("NextToken").getter(getter(ListExportsResponse::nextToken)).setter(setter(Builder::nextToken))
            .traits(LocationTrait.builder().location(MarshallLocation.PAYLOAD).locationName("NextToken").build()).build();

    private static final List<SdkField<?>> SDK_FIELDS = Collections.unmodifiableList(Arrays.asList(EXPORT_SUMMARIES_FIELD,
            NEXT_TOKEN_FIELD));

    private final List<ExportSummary> exportSummaries;

    private final String nextToken;

    private ListExportsResponse(BuilderImpl builder) {
        super(builder);
        this.exportSummaries = builder.exportSummaries;
        this.nextToken = builder.nextToken;
    }

    /**
     * For responses, this returns true if the service returned a value for the ExportSummaries property. This DOES NOT
     * check that the value is non-empty (for which, you should check the {@code isEmpty()} method on the property).
     * This is useful because the SDK will never return a null collection or map, but you may need to differentiate
     * between the service returning nothing (or null) and the service returning an empty collection or map. For
     * requests, this returns true if a value for the property was specified in the request builder, and false if a
     * value was not specified.
     */
    public final boolean hasExportSummaries() {
        return exportSummaries != null && !(exportSummaries instanceof SdkAutoConstructList);
    }

    /**
     * <p>
     * A list of <code>ExportSummary</code> objects.
     * </p>
     * <p>
     * Attempts to modify the collection returned by this method will result in an UnsupportedOperationException.
     * </p>
     * <p>
     * This method will never return null. If you would like to know whether the service returned this field (so that
     * you can differentiate between null and empty), you can use the {@link #hasExportSummaries} method.
     * </p>
     * 
     * @return A list of <code>ExportSummary</code> objects.
     */
    public final List<ExportSummary> exportSummaries() {
        return exportSummaries;
    }

    /**
     * <p>
     * If this value is returned, there are additional results to be displayed. To retrieve them, call
     * <code>ListExports</code> again, with <code>NextToken</code> set to this value.
     * </p>
     * 
     * @return If this value is returned, there are additional results to be displayed. To retrieve them, call
     *         <code>ListExports</code> again, with <code>NextToken</code> set to this value.
     */
    public final String nextToken() {
        return nextToken;
    }

    @Override
    public Builder toBuilder() {
        return new BuilderImpl(this);
    }

    public static Builder builder() {
        return new BuilderImpl();
    }

    public static Class<? extends Builder> serializableBuilderClass() {
        return BuilderImpl.class;
    }

    @Override
    public final int hashCode() {
        int hashCode = 1;
        hashCode = 31 * hashCode + super.hashCode();
        hashCode = 31 * hashCode + Objects.hashCode(hasExportSummaries() ? exportSummaries() : null);
        hashCode = 31 * hashCode + Objects.hashCode(nextToken());
        return hashCode;
    }

    @Override
    public final boolean equals(Object obj) {
        return super.equals(obj) && equalsBySdkFields(obj);
    }

    @Override
    public final boolean equalsBySdkFields(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (!(obj instanceof ListExportsResponse)) {
            return false;
        }
        ListExportsResponse other = (ListExportsResponse) obj;
        return hasExportSummaries() == other.hasExportSummaries() && Objects.equals(exportSummaries(), other.exportSummaries())
                && Objects.equals(nextToken(), other.nextToken());
    }

    /**
     * Returns a string representation of this object. This is useful for testing and debugging. Sensitive data will be
     * redacted from this string using a placeholder value.
     */
    @Override
    public final String toString() {
        return ToString.builder("ListExportsResponse").add("ExportSummaries", hasExportSummaries() ? exportSummaries() : null)
                .add("NextToken", nextToken()).build();
    }

    public final <T> Optional<T> getValueForField(String fieldName, Class<T> clazz) {
        switch (fieldName) {
        case "ExportSummaries":
            return Optional.ofNullable(clazz.cast(exportSummaries()));
        case "NextToken":
            return Optional.ofNullable(clazz.cast(nextToken()));
        default:
            return Optional.empty();
        }
    }

    @Override
    public final List<SdkField<?>> sdkFields() {
        return SDK_FIELDS;
    }

    private static <T> Function<Object, T> getter(Function<ListExportsResponse, T> g) {
        return obj -> g.apply((ListExportsResponse) obj);
    }

    private static <T> BiConsumer<Object, T> setter(BiConsumer<Builder, T> s) {
        return (obj, val) -> s.accept((Builder) obj, val);
    }

    public interface Builder extends DynamoDbResponse.Builder, SdkPojo, CopyableBuilder<Builder, ListExportsResponse> {
        /**
         * <p>
         * A list of <code>ExportSummary</code> objects.
         * </p>
         * 
         * @param exportSummaries
         *        A list of <code>ExportSummary</code> objects.
         * @return Returns a reference to this object so that method calls can be chained together.
         */
        Builder exportSummaries(Collection<ExportSummary> exportSummaries);

        /**
         * <p>
         * A list of <code>ExportSummary</code> objects.
         * </p>
         * 
         * @param exportSummaries
         *        A list of <code>ExportSummary</code> objects.
         * @return Returns a reference to this object so that method calls can be chained together.
         */
        Builder exportSummaries(ExportSummary... exportSummaries);

        /**
         * <p>
         * A list of <code>ExportSummary</code> objects.
         * </p>
         * This is a convenience method that creates an instance of the
         * {@link software.amazon.awssdk.services.dynamodb.model.ExportSummary.Builder} avoiding the need to create one
         * manually via {@link software.amazon.awssdk.services.dynamodb.model.ExportSummary#builder()}.
         *
         * <p>
         * When the {@link Consumer} completes,
         * {@link software.amazon.awssdk.services.dynamodb.model.ExportSummary.Builder#build()} is called immediately
         * and its result is passed to {@link #exportSummaries(List<ExportSummary>)}.
         * 
         * @param exportSummaries
         *        a consumer that will call methods on
         *        {@link software.amazon.awssdk.services.dynamodb.model.ExportSummary.Builder}
         * @return Returns a reference to this object so that method calls can be chained together.
         * @see #exportSummaries(java.util.Collection<ExportSummary>)
         */
        Builder exportSummaries(Consumer<ExportSummary.Builder>... exportSummaries);

        /**
         * <p>
         * If this value is returned, there are additional results to be displayed. To retrieve them, call
         * <code>ListExports</code> again, with <code>NextToken</code> set to this value.
         * </p>
         * 
         * @param nextToken
         *        If this value is returned, there are additional results to be displayed. To retrieve them, call
         *        <code>ListExports</code> again, with <code>NextToken</code> set to this value.
         * @return Returns a reference to this object so that method calls can be chained together.
         */
        Builder nextToken(String nextToken);
    }

    static final class BuilderImpl extends DynamoDbResponse.BuilderImpl implements Builder {
        private List<ExportSummary> exportSummaries = DefaultSdkAutoConstructList.getInstance();

        private String nextToken;

        private BuilderImpl() {
        }

        private BuilderImpl(ListExportsResponse model) {
            super(model);
            exportSummaries(model.exportSummaries);
            nextToken(model.nextToken);
        }

        public final List<ExportSummary.Builder> getExportSummaries() {
            List<ExportSummary.Builder> result = ExportSummariesCopier.copyToBuilder(this.exportSummaries);
            if (result instanceof SdkAutoConstructList) {
                return null;
            }
            return result;
        }

        public final void setExportSummaries(Collection<ExportSummary.BuilderImpl> exportSummaries) {
            this.exportSummaries = ExportSummariesCopier.copyFromBuilder(exportSummaries);
        }

        @Override
        public final Builder exportSummaries(Collection<ExportSummary> exportSummaries) {
            this.exportSummaries = ExportSummariesCopier.copy(exportSummaries);
            return this;
        }

        @Override
        @SafeVarargs
        public final Builder exportSummaries(ExportSummary... exportSummaries) {
            exportSummaries(Arrays.asList(exportSummaries));
            return this;
        }

        @Override
        @SafeVarargs
        public final Builder exportSummaries(Consumer<ExportSummary.Builder>... exportSummaries) {
            exportSummaries(Stream.of(exportSummaries).map(c -> ExportSummary.builder().applyMutation(c).build())
                    .collect(Collectors.toList()));
            return this;
        }

        public final String getNextToken() {
            return nextToken;
        }

        public final void setNextToken(String nextToken) {
            this.nextToken = nextToken;
        }

        @Override
        public final Builder nextToken(String nextToken) {
            this.nextToken = nextToken;
            return this;
        }

        @Override
        public ListExportsResponse build() {
            return new ListExportsResponse(this);
        }

        @Override
        public List<SdkField<?>> sdkFields() {
            return SDK_FIELDS;
        }
    }
}
