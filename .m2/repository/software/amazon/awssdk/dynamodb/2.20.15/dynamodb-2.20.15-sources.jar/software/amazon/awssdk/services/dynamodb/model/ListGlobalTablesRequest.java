/*
 * Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
 * 
 * Licensed under the Apache License, Version 2.0 (the "License"). You may not use this file except in compliance with
 * the License. A copy of the License is located at
 * 
 * http://aws.amazon.com/apache2.0
 * 
 * or in the "license" file accompanying this file. This file is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR
 * CONDITIONS OF ANY KIND, either express or implied. See the License for the specific language governing permissions
 * and limitations under the License.
 */

package software.amazon.awssdk.services.dynamodb.model;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.function.BiConsumer;
import java.util.function.Consumer;
import java.util.function.Function;
import software.amazon.awssdk.annotations.Generated;
import software.amazon.awssdk.awscore.AwsRequestOverrideConfiguration;
import software.amazon.awssdk.core.SdkField;
import software.amazon.awssdk.core.SdkPojo;
import software.amazon.awssdk.core.protocol.MarshallLocation;
import software.amazon.awssdk.core.protocol.MarshallingType;
import software.amazon.awssdk.core.traits.LocationTrait;
import software.amazon.awssdk.utils.ToString;
import software.amazon.awssdk.utils.builder.CopyableBuilder;
import software.amazon.awssdk.utils.builder.ToCopyableBuilder;

/**
 */
@Generated("software.amazon.awssdk:codegen")
public final class ListGlobalTablesRequest extends DynamoDbRequest implements
        ToCopyableBuilder<ListGlobalTablesRequest.Builder, ListGlobalTablesRequest> {
    private static final SdkField<String> EXCLUSIVE_START_GLOBAL_TABLE_NAME_FIELD = SdkField
            .<String> builder(MarshallingType.STRING)
            .memberName("ExclusiveStartGlobalTableName")
            .getter(getter(ListGlobalTablesRequest::exclusiveStartGlobalTableName))
            .setter(setter(Builder::exclusiveStartGlobalTableName))
            .traits(LocationTrait.builder().location(MarshallLocation.PAYLOAD).locationName("ExclusiveStartGlobalTableName")
                    .build()).build();

    private static final SdkField<Integer> LIMIT_FIELD = SdkField.<Integer> builder(MarshallingType.INTEGER).memberName("Limit")
            .getter(getter(ListGlobalTablesRequest::limit)).setter(setter(Builder::limit))
            .traits(LocationTrait.builder().location(MarshallLocation.PAYLOAD).locationName("Limit").build()).build();

    private static final SdkField<String> REGION_NAME_FIELD = SdkField.<String> builder(MarshallingType.STRING)
            .memberName("RegionName").getter(getter(ListGlobalTablesRequest::regionName)).setter(setter(Builder::regionName))
            .traits(LocationTrait.builder().location(MarshallLocation.PAYLOAD).locationName("RegionName").build()).build();

    private static final List<SdkField<?>> SDK_FIELDS = Collections.unmodifiableList(Arrays.asList(
            EXCLUSIVE_START_GLOBAL_TABLE_NAME_FIELD, LIMIT_FIELD, REGION_NAME_FIELD));

    private final String exclusiveStartGlobalTableName;

    private final Integer limit;

    private final String regionName;

    private ListGlobalTablesRequest(BuilderImpl builder) {
        super(builder);
        this.exclusiveStartGlobalTableName = builder.exclusiveStartGlobalTableName;
        this.limit = builder.limit;
        this.regionName = builder.regionName;
    }

    /**
     * <p>
     * The first global table name that this operation will evaluate.
     * </p>
     * 
     * @return The first global table name that this operation will evaluate.
     */
    public final String exclusiveStartGlobalTableName() {
        return exclusiveStartGlobalTableName;
    }

    /**
     * <p>
     * The maximum number of table names to return, if the parameter is not specified DynamoDB defaults to 100.
     * </p>
     * <p>
     * If the number of global tables DynamoDB finds reaches this limit, it stops the operation and returns the table
     * names collected up to that point, with a table name in the <code>LastEvaluatedGlobalTableName</code> to apply in
     * a subsequent operation to the <code>ExclusiveStartGlobalTableName</code> parameter.
     * </p>
     * 
     * @return The maximum number of table names to return, if the parameter is not specified DynamoDB defaults to
     *         100.</p>
     *         <p>
     *         If the number of global tables DynamoDB finds reaches this limit, it stops the operation and returns the
     *         table names collected up to that point, with a table name in the
     *         <code>LastEvaluatedGlobalTableName</code> to apply in a subsequent operation to the
     *         <code>ExclusiveStartGlobalTableName</code> parameter.
     */
    public final Integer limit() {
        return limit;
    }

    /**
     * <p>
     * Lists the global tables in a specific Region.
     * </p>
     * 
     * @return Lists the global tables in a specific Region.
     */
    public final String regionName() {
        return regionName;
    }

    @Override
    public Builder toBuilder() {
        return new BuilderImpl(this);
    }

    public static Builder builder() {
        return new BuilderImpl();
    }

    public static Class<? extends Builder> serializableBuilderClass() {
        return BuilderImpl.class;
    }

    @Override
    public final int hashCode() {
        int hashCode = 1;
        hashCode = 31 * hashCode + super.hashCode();
        hashCode = 31 * hashCode + Objects.hashCode(exclusiveStartGlobalTableName());
        hashCode = 31 * hashCode + Objects.hashCode(limit());
        hashCode = 31 * hashCode + Objects.hashCode(regionName());
        return hashCode;
    }

    @Override
    public final boolean equals(Object obj) {
        return super.equals(obj) && equalsBySdkFields(obj);
    }

    @Override
    public final boolean equalsBySdkFields(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (!(obj instanceof ListGlobalTablesRequest)) {
            return false;
        }
        ListGlobalTablesRequest other = (ListGlobalTablesRequest) obj;
        return Objects.equals(exclusiveStartGlobalTableName(), other.exclusiveStartGlobalTableName())
                && Objects.equals(limit(), other.limit()) && Objects.equals(regionName(), other.regionName());
    }

    /**
     * Returns a string representation of this object. This is useful for testing and debugging. Sensitive data will be
     * redacted from this string using a placeholder value.
     */
    @Override
    public final String toString() {
        return ToString.builder("ListGlobalTablesRequest").add("ExclusiveStartGlobalTableName", exclusiveStartGlobalTableName())
                .add("Limit", limit()).add("RegionName", regionName()).build();
    }

    public final <T> Optional<T> getValueForField(String fieldName, Class<T> clazz) {
        switch (fieldName) {
        case "ExclusiveStartGlobalTableName":
            return Optional.ofNullable(clazz.cast(exclusiveStartGlobalTableName()));
        case "Limit":
            return Optional.ofNullable(clazz.cast(limit()));
        case "RegionName":
            return Optional.ofNullable(clazz.cast(regionName()));
        default:
            return Optional.empty();
        }
    }

    @Override
    public final List<SdkField<?>> sdkFields() {
        return SDK_FIELDS;
    }

    private static <T> Function<Object, T> getter(Function<ListGlobalTablesRequest, T> g) {
        return obj -> g.apply((ListGlobalTablesRequest) obj);
    }

    private static <T> BiConsumer<Object, T> setter(BiConsumer<Builder, T> s) {
        return (obj, val) -> s.accept((Builder) obj, val);
    }

    public interface Builder extends DynamoDbRequest.Builder, SdkPojo, CopyableBuilder<Builder, ListGlobalTablesRequest> {
        /**
         * <p>
         * The first global table name that this operation will evaluate.
         * </p>
         * 
         * @param exclusiveStartGlobalTableName
         *        The first global table name that this operation will evaluate.
         * @return Returns a reference to this object so that method calls can be chained together.
         */
        Builder exclusiveStartGlobalTableName(String exclusiveStartGlobalTableName);

        /**
         * <p>
         * The maximum number of table names to return, if the parameter is not specified DynamoDB defaults to 100.
         * </p>
         * <p>
         * If the number of global tables DynamoDB finds reaches this limit, it stops the operation and returns the
         * table names collected up to that point, with a table name in the <code>LastEvaluatedGlobalTableName</code> to
         * apply in a subsequent operation to the <code>ExclusiveStartGlobalTableName</code> parameter.
         * </p>
         * 
         * @param limit
         *        The maximum number of table names to return, if the parameter is not specified DynamoDB defaults to
         *        100.</p>
         *        <p>
         *        If the number of global tables DynamoDB finds reaches this limit, it stops the operation and returns
         *        the table names collected up to that point, with a table name in the
         *        <code>LastEvaluatedGlobalTableName</code> to apply in a subsequent operation to the
         *        <code>ExclusiveStartGlobalTableName</code> parameter.
         * @return Returns a reference to this object so that method calls can be chained together.
         */
        Builder limit(Integer limit);

        /**
         * <p>
         * Lists the global tables in a specific Region.
         * </p>
         * 
         * @param regionName
         *        Lists the global tables in a specific Region.
         * @return Returns a reference to this object so that method calls can be chained together.
         */
        Builder regionName(String regionName);

        @Override
        Builder overrideConfiguration(AwsRequestOverrideConfiguration overrideConfiguration);

        @Override
        Builder overrideConfiguration(Consumer<AwsRequestOverrideConfiguration.Builder> builderConsumer);
    }

    static final class BuilderImpl extends DynamoDbRequest.BuilderImpl implements Builder {
        private String exclusiveStartGlobalTableName;

        private Integer limit;

        private String regionName;

        private BuilderImpl() {
        }

        private BuilderImpl(ListGlobalTablesRequest model) {
            super(model);
            exclusiveStartGlobalTableName(model.exclusiveStartGlobalTableName);
            limit(model.limit);
            regionName(model.regionName);
        }

        public final String getExclusiveStartGlobalTableName() {
            return exclusiveStartGlobalTableName;
        }

        public final void setExclusiveStartGlobalTableName(String exclusiveStartGlobalTableName) {
            this.exclusiveStartGlobalTableName = exclusiveStartGlobalTableName;
        }

        @Override
        public final Builder exclusiveStartGlobalTableName(String exclusiveStartGlobalTableName) {
            this.exclusiveStartGlobalTableName = exclusiveStartGlobalTableName;
            return this;
        }

        public final Integer getLimit() {
            return limit;
        }

        public final void setLimit(Integer limit) {
            this.limit = limit;
        }

        @Override
        public final Builder limit(Integer limit) {
            this.limit = limit;
            return this;
        }

        public final String getRegionName() {
            return regionName;
        }

        public final void setRegionName(String regionName) {
            this.regionName = regionName;
        }

        @Override
        public final Builder regionName(String regionName) {
            this.regionName = regionName;
            return this;
        }

        @Override
        public Builder overrideConfiguration(AwsRequestOverrideConfiguration overrideConfiguration) {
            super.overrideConfiguration(overrideConfiguration);
            return this;
        }

        @Override
        public Builder overrideConfiguration(Consumer<AwsRequestOverrideConfiguration.Builder> builderConsumer) {
            super.overrideConfiguration(builderConsumer);
            return this;
        }

        @Override
        public ListGlobalTablesRequest build() {
            return new ListGlobalTablesRequest(this);
        }

        @Override
        public List<SdkField<?>> sdkFields() {
            return SDK_FIELDS;
        }
    }
}
