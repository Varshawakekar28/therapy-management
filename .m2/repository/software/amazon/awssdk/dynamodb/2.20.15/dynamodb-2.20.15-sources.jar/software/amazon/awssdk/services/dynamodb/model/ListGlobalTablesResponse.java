/*
 * Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
 * 
 * Licensed under the Apache License, Version 2.0 (the "License"). You may not use this file except in compliance with
 * the License. A copy of the License is located at
 * 
 * http://aws.amazon.com/apache2.0
 * 
 * or in the "license" file accompanying this file. This file is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR
 * CONDITIONS OF ANY KIND, either express or implied. See the License for the specific language governing permissions
 * and limitations under the License.
 */

package software.amazon.awssdk.services.dynamodb.model;

import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.function.BiConsumer;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.stream.Collectors;
import java.util.stream.Stream;
import software.amazon.awssdk.annotations.Generated;
import software.amazon.awssdk.core.SdkField;
import software.amazon.awssdk.core.SdkPojo;
import software.amazon.awssdk.core.protocol.MarshallLocation;
import software.amazon.awssdk.core.protocol.MarshallingType;
import software.amazon.awssdk.core.traits.ListTrait;
import software.amazon.awssdk.core.traits.LocationTrait;
import software.amazon.awssdk.core.util.DefaultSdkAutoConstructList;
import software.amazon.awssdk.core.util.SdkAutoConstructList;
import software.amazon.awssdk.utils.ToString;
import software.amazon.awssdk.utils.builder.CopyableBuilder;
import software.amazon.awssdk.utils.builder.ToCopyableBuilder;

/**
 */
@Generated("software.amazon.awssdk:codegen")
public final class ListGlobalTablesResponse extends DynamoDbResponse implements
        ToCopyableBuilder<ListGlobalTablesResponse.Builder, ListGlobalTablesResponse> {
    private static final SdkField<List<GlobalTable>> GLOBAL_TABLES_FIELD = SdkField
            .<List<GlobalTable>> builder(MarshallingType.LIST)
            .memberName("GlobalTables")
            .getter(getter(ListGlobalTablesResponse::globalTables))
            .setter(setter(Builder::globalTables))
            .traits(LocationTrait.builder().location(MarshallLocation.PAYLOAD).locationName("GlobalTables").build(),
                    ListTrait
                            .builder()
                            .memberLocationName(null)
                            .memberFieldInfo(
                                    SdkField.<GlobalTable> builder(MarshallingType.SDK_POJO)
                                            .constructor(GlobalTable::builder)
                                            .traits(LocationTrait.builder().location(MarshallLocation.PAYLOAD)
                                                    .locationName("member").build()).build()).build()).build();

    private static final SdkField<String> LAST_EVALUATED_GLOBAL_TABLE_NAME_FIELD = SdkField
            .<String> builder(MarshallingType.STRING)
            .memberName("LastEvaluatedGlobalTableName")
            .getter(getter(ListGlobalTablesResponse::lastEvaluatedGlobalTableName))
            .setter(setter(Builder::lastEvaluatedGlobalTableName))
            .traits(LocationTrait.builder().location(MarshallLocation.PAYLOAD).locationName("LastEvaluatedGlobalTableName")
                    .build()).build();

    private static final List<SdkField<?>> SDK_FIELDS = Collections.unmodifiableList(Arrays.asList(GLOBAL_TABLES_FIELD,
            LAST_EVALUATED_GLOBAL_TABLE_NAME_FIELD));

    private final List<GlobalTable> globalTables;

    private final String lastEvaluatedGlobalTableName;

    private ListGlobalTablesResponse(BuilderImpl builder) {
        super(builder);
        this.globalTables = builder.globalTables;
        this.lastEvaluatedGlobalTableName = builder.lastEvaluatedGlobalTableName;
    }

    /**
     * For responses, this returns true if the service returned a value for the GlobalTables property. This DOES NOT
     * check that the value is non-empty (for which, you should check the {@code isEmpty()} method on the property).
     * This is useful because the SDK will never return a null collection or map, but you may need to differentiate
     * between the service returning nothing (or null) and the service returning an empty collection or map. For
     * requests, this returns true if a value for the property was specified in the request builder, and false if a
     * value was not specified.
     */
    public final boolean hasGlobalTables() {
        return globalTables != null && !(globalTables instanceof SdkAutoConstructList);
    }

    /**
     * <p>
     * List of global table names.
     * </p>
     * <p>
     * Attempts to modify the collection returned by this method will result in an UnsupportedOperationException.
     * </p>
     * <p>
     * This method will never return null. If you would like to know whether the service returned this field (so that
     * you can differentiate between null and empty), you can use the {@link #hasGlobalTables} method.
     * </p>
     * 
     * @return List of global table names.
     */
    public final List<GlobalTable> globalTables() {
        return globalTables;
    }

    /**
     * <p>
     * Last evaluated global table name.
     * </p>
     * 
     * @return Last evaluated global table name.
     */
    public final String lastEvaluatedGlobalTableName() {
        return lastEvaluatedGlobalTableName;
    }

    @Override
    public Builder toBuilder() {
        return new BuilderImpl(this);
    }

    public static Builder builder() {
        return new BuilderImpl();
    }

    public static Class<? extends Builder> serializableBuilderClass() {
        return BuilderImpl.class;
    }

    @Override
    public final int hashCode() {
        int hashCode = 1;
        hashCode = 31 * hashCode + super.hashCode();
        hashCode = 31 * hashCode + Objects.hashCode(hasGlobalTables() ? globalTables() : null);
        hashCode = 31 * hashCode + Objects.hashCode(lastEvaluatedGlobalTableName());
        return hashCode;
    }

    @Override
    public final boolean equals(Object obj) {
        return super.equals(obj) && equalsBySdkFields(obj);
    }

    @Override
    public final boolean equalsBySdkFields(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (!(obj instanceof ListGlobalTablesResponse)) {
            return false;
        }
        ListGlobalTablesResponse other = (ListGlobalTablesResponse) obj;
        return hasGlobalTables() == other.hasGlobalTables() && Objects.equals(globalTables(), other.globalTables())
                && Objects.equals(lastEvaluatedGlobalTableName(), other.lastEvaluatedGlobalTableName());
    }

    /**
     * Returns a string representation of this object. This is useful for testing and debugging. Sensitive data will be
     * redacted from this string using a placeholder value.
     */
    @Override
    public final String toString() {
        return ToString.builder("ListGlobalTablesResponse").add("GlobalTables", hasGlobalTables() ? globalTables() : null)
                .add("LastEvaluatedGlobalTableName", lastEvaluatedGlobalTableName()).build();
    }

    public final <T> Optional<T> getValueForField(String fieldName, Class<T> clazz) {
        switch (fieldName) {
        case "GlobalTables":
            return Optional.ofNullable(clazz.cast(globalTables()));
        case "LastEvaluatedGlobalTableName":
            return Optional.ofNullable(clazz.cast(lastEvaluatedGlobalTableName()));
        default:
            return Optional.empty();
        }
    }

    @Override
    public final List<SdkField<?>> sdkFields() {
        return SDK_FIELDS;
    }

    private static <T> Function<Object, T> getter(Function<ListGlobalTablesResponse, T> g) {
        return obj -> g.apply((ListGlobalTablesResponse) obj);
    }

    private static <T> BiConsumer<Object, T> setter(BiConsumer<Builder, T> s) {
        return (obj, val) -> s.accept((Builder) obj, val);
    }

    public interface Builder extends DynamoDbResponse.Builder, SdkPojo, CopyableBuilder<Builder, ListGlobalTablesResponse> {
        /**
         * <p>
         * List of global table names.
         * </p>
         * 
         * @param globalTables
         *        List of global table names.
         * @return Returns a reference to this object so that method calls can be chained together.
         */
        Builder globalTables(Collection<GlobalTable> globalTables);

        /**
         * <p>
         * List of global table names.
         * </p>
         * 
         * @param globalTables
         *        List of global table names.
         * @return Returns a reference to this object so that method calls can be chained together.
         */
        Builder globalTables(GlobalTable... globalTables);

        /**
         * <p>
         * List of global table names.
         * </p>
         * This is a convenience method that creates an instance of the
         * {@link software.amazon.awssdk.services.dynamodb.model.GlobalTable.Builder} avoiding the need to create one
         * manually via {@link software.amazon.awssdk.services.dynamodb.model.GlobalTable#builder()}.
         *
         * <p>
         * When the {@link Consumer} completes,
         * {@link software.amazon.awssdk.services.dynamodb.model.GlobalTable.Builder#build()} is called immediately and
         * its result is passed to {@link #globalTables(List<GlobalTable>)}.
         * 
         * @param globalTables
         *        a consumer that will call methods on
         *        {@link software.amazon.awssdk.services.dynamodb.model.GlobalTable.Builder}
         * @return Returns a reference to this object so that method calls can be chained together.
         * @see #globalTables(java.util.Collection<GlobalTable>)
         */
        Builder globalTables(Consumer<GlobalTable.Builder>... globalTables);

        /**
         * <p>
         * Last evaluated global table name.
         * </p>
         * 
         * @param lastEvaluatedGlobalTableName
         *        Last evaluated global table name.
         * @return Returns a reference to this object so that method calls can be chained together.
         */
        Builder lastEvaluatedGlobalTableName(String lastEvaluatedGlobalTableName);
    }

    static final class BuilderImpl extends DynamoDbResponse.BuilderImpl implements Builder {
        private List<GlobalTable> globalTables = DefaultSdkAutoConstructList.getInstance();

        private String lastEvaluatedGlobalTableName;

        private BuilderImpl() {
        }

        private BuilderImpl(ListGlobalTablesResponse model) {
            super(model);
            globalTables(model.globalTables);
            lastEvaluatedGlobalTableName(model.lastEvaluatedGlobalTableName);
        }

        public final List<GlobalTable.Builder> getGlobalTables() {
            List<GlobalTable.Builder> result = GlobalTableListCopier.copyToBuilder(this.globalTables);
            if (result instanceof SdkAutoConstructList) {
                return null;
            }
            return result;
        }

        public final void setGlobalTables(Collection<GlobalTable.BuilderImpl> globalTables) {
            this.globalTables = GlobalTableListCopier.copyFromBuilder(globalTables);
        }

        @Override
        public final Builder globalTables(Collection<GlobalTable> globalTables) {
            this.globalTables = GlobalTableListCopier.copy(globalTables);
            return this;
        }

        @Override
        @SafeVarargs
        public final Builder globalTables(GlobalTable... globalTables) {
            globalTables(Arrays.asList(globalTables));
            return this;
        }

        @Override
        @SafeVarargs
        public final Builder globalTables(Consumer<GlobalTable.Builder>... globalTables) {
            globalTables(Stream.of(globalTables).map(c -> GlobalTable.builder().applyMutation(c).build())
                    .collect(Collectors.toList()));
            return this;
        }

        public final String getLastEvaluatedGlobalTableName() {
            return lastEvaluatedGlobalTableName;
        }

        public final void setLastEvaluatedGlobalTableName(String lastEvaluatedGlobalTableName) {
            this.lastEvaluatedGlobalTableName = lastEvaluatedGlobalTableName;
        }

        @Override
        public final Builder lastEvaluatedGlobalTableName(String lastEvaluatedGlobalTableName) {
            this.lastEvaluatedGlobalTableName = lastEvaluatedGlobalTableName;
            return this;
        }

        @Override
        public ListGlobalTablesResponse build() {
            return new ListGlobalTablesResponse(this);
        }

        @Override
        public List<SdkField<?>> sdkFields() {
            return SDK_FIELDS;
        }
    }
}
