/*
 * Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
 * 
 * Licensed under the Apache License, Version 2.0 (the "License"). You may not use this file except in compliance with
 * the License. A copy of the License is located at
 * 
 * http://aws.amazon.com/apache2.0
 * 
 * or in the "license" file accompanying this file. This file is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR
 * CONDITIONS OF ANY KIND, either express or implied. See the License for the specific language governing permissions
 * and limitations under the License.
 */

package software.amazon.awssdk.services.dynamodb.model;

import java.io.Serializable;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.function.BiConsumer;
import java.util.function.Function;
import software.amazon.awssdk.annotations.Generated;
import software.amazon.awssdk.core.SdkField;
import software.amazon.awssdk.core.SdkPojo;
import software.amazon.awssdk.core.protocol.MarshallLocation;
import software.amazon.awssdk.core.protocol.MarshallingType;
import software.amazon.awssdk.core.traits.LocationTrait;
import software.amazon.awssdk.utils.ToString;
import software.amazon.awssdk.utils.builder.CopyableBuilder;
import software.amazon.awssdk.utils.builder.ToCopyableBuilder;

/**
 * <p>
 * Represents the settings used to enable server-side encryption.
 * </p>
 */
@Generated("software.amazon.awssdk:codegen")
public final class SSESpecification implements SdkPojo, Serializable,
        ToCopyableBuilder<SSESpecification.Builder, SSESpecification> {
    private static final SdkField<Boolean> ENABLED_FIELD = SdkField.<Boolean> builder(MarshallingType.BOOLEAN)
            .memberName("Enabled").getter(getter(SSESpecification::enabled)).setter(setter(Builder::enabled))
            .traits(LocationTrait.builder().location(MarshallLocation.PAYLOAD).locationName("Enabled").build()).build();

    private static final SdkField<String> SSE_TYPE_FIELD = SdkField.<String> builder(MarshallingType.STRING)
            .memberName("SSEType").getter(getter(SSESpecification::sseTypeAsString)).setter(setter(Builder::sseType))
            .traits(LocationTrait.builder().location(MarshallLocation.PAYLOAD).locationName("SSEType").build()).build();

    private static final SdkField<String> KMS_MASTER_KEY_ID_FIELD = SdkField.<String> builder(MarshallingType.STRING)
            .memberName("KMSMasterKeyId").getter(getter(SSESpecification::kmsMasterKeyId))
            .setter(setter(Builder::kmsMasterKeyId))
            .traits(LocationTrait.builder().location(MarshallLocation.PAYLOAD).locationName("KMSMasterKeyId").build()).build();

    private static final List<SdkField<?>> SDK_FIELDS = Collections.unmodifiableList(Arrays.asList(ENABLED_FIELD, SSE_TYPE_FIELD,
            KMS_MASTER_KEY_ID_FIELD));

    private static final long serialVersionUID = 1L;

    private final Boolean enabled;

    private final String sseType;

    private final String kmsMasterKeyId;

    private SSESpecification(BuilderImpl builder) {
        this.enabled = builder.enabled;
        this.sseType = builder.sseType;
        this.kmsMasterKeyId = builder.kmsMasterKeyId;
    }

    /**
     * <p>
     * Indicates whether server-side encryption is done using an Amazon Web Services managed key or an Amazon Web
     * Services owned key. If enabled (true), server-side encryption type is set to <code>KMS</code> and an Amazon Web
     * Services managed key is used (KMS charges apply). If disabled (false) or not specified, server-side encryption is
     * set to Amazon Web Services owned key.
     * </p>
     * 
     * @return Indicates whether server-side encryption is done using an Amazon Web Services managed key or an Amazon
     *         Web Services owned key. If enabled (true), server-side encryption type is set to <code>KMS</code> and an
     *         Amazon Web Services managed key is used (KMS charges apply). If disabled (false) or not specified,
     *         server-side encryption is set to Amazon Web Services owned key.
     */
    public final Boolean enabled() {
        return enabled;
    }

    /**
     * <p>
     * Server-side encryption type. The only supported value is:
     * </p>
     * <ul>
     * <li>
     * <p>
     * <code>KMS</code> - Server-side encryption that uses Key Management Service. The key is stored in your account and
     * is managed by KMS (KMS charges apply).
     * </p>
     * </li>
     * </ul>
     * <p>
     * If the service returns an enum value that is not available in the current SDK version, {@link #sseType} will
     * return {@link SSEType#UNKNOWN_TO_SDK_VERSION}. The raw value returned by the service is available from
     * {@link #sseTypeAsString}.
     * </p>
     * 
     * @return Server-side encryption type. The only supported value is:</p>
     *         <ul>
     *         <li>
     *         <p>
     *         <code>KMS</code> - Server-side encryption that uses Key Management Service. The key is stored in your
     *         account and is managed by KMS (KMS charges apply).
     *         </p>
     *         </li>
     * @see SSEType
     */
    public final SSEType sseType() {
        return SSEType.fromValue(sseType);
    }

    /**
     * <p>
     * Server-side encryption type. The only supported value is:
     * </p>
     * <ul>
     * <li>
     * <p>
     * <code>KMS</code> - Server-side encryption that uses Key Management Service. The key is stored in your account and
     * is managed by KMS (KMS charges apply).
     * </p>
     * </li>
     * </ul>
     * <p>
     * If the service returns an enum value that is not available in the current SDK version, {@link #sseType} will
     * return {@link SSEType#UNKNOWN_TO_SDK_VERSION}. The raw value returned by the service is available from
     * {@link #sseTypeAsString}.
     * </p>
     * 
     * @return Server-side encryption type. The only supported value is:</p>
     *         <ul>
     *         <li>
     *         <p>
     *         <code>KMS</code> - Server-side encryption that uses Key Management Service. The key is stored in your
     *         account and is managed by KMS (KMS charges apply).
     *         </p>
     *         </li>
     * @see SSEType
     */
    public final String sseTypeAsString() {
        return sseType;
    }

    /**
     * <p>
     * The KMS key that should be used for the KMS encryption. To specify a key, use its key ID, Amazon Resource Name
     * (ARN), alias name, or alias ARN. Note that you should only provide this parameter if the key is different from
     * the default DynamoDB key <code>alias/aws/dynamodb</code>.
     * </p>
     * 
     * @return The KMS key that should be used for the KMS encryption. To specify a key, use its key ID, Amazon Resource
     *         Name (ARN), alias name, or alias ARN. Note that you should only provide this parameter if the key is
     *         different from the default DynamoDB key <code>alias/aws/dynamodb</code>.
     */
    public final String kmsMasterKeyId() {
        return kmsMasterKeyId;
    }

    @Override
    public Builder toBuilder() {
        return new BuilderImpl(this);
    }

    public static Builder builder() {
        return new BuilderImpl();
    }

    public static Class<? extends Builder> serializableBuilderClass() {
        return BuilderImpl.class;
    }

    @Override
    public final int hashCode() {
        int hashCode = 1;
        hashCode = 31 * hashCode + Objects.hashCode(enabled());
        hashCode = 31 * hashCode + Objects.hashCode(sseTypeAsString());
        hashCode = 31 * hashCode + Objects.hashCode(kmsMasterKeyId());
        return hashCode;
    }

    @Override
    public final boolean equals(Object obj) {
        return equalsBySdkFields(obj);
    }

    @Override
    public final boolean equalsBySdkFields(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (!(obj instanceof SSESpecification)) {
            return false;
        }
        SSESpecification other = (SSESpecification) obj;
        return Objects.equals(enabled(), other.enabled()) && Objects.equals(sseTypeAsString(), other.sseTypeAsString())
                && Objects.equals(kmsMasterKeyId(), other.kmsMasterKeyId());
    }

    /**
     * Returns a string representation of this object. This is useful for testing and debugging. Sensitive data will be
     * redacted from this string using a placeholder value.
     */
    @Override
    public final String toString() {
        return ToString.builder("SSESpecification").add("Enabled", enabled()).add("SSEType", sseTypeAsString())
                .add("KMSMasterKeyId", kmsMasterKeyId()).build();
    }

    public final <T> Optional<T> getValueForField(String fieldName, Class<T> clazz) {
        switch (fieldName) {
        case "Enabled":
            return Optional.ofNullable(clazz.cast(enabled()));
        case "SSEType":
            return Optional.ofNullable(clazz.cast(sseTypeAsString()));
        case "KMSMasterKeyId":
            return Optional.ofNullable(clazz.cast(kmsMasterKeyId()));
        default:
            return Optional.empty();
        }
    }

    @Override
    public final List<SdkField<?>> sdkFields() {
        return SDK_FIELDS;
    }

    private static <T> Function<Object, T> getter(Function<SSESpecification, T> g) {
        return obj -> g.apply((SSESpecification) obj);
    }

    private static <T> BiConsumer<Object, T> setter(BiConsumer<Builder, T> s) {
        return (obj, val) -> s.accept((Builder) obj, val);
    }

    public interface Builder extends SdkPojo, CopyableBuilder<Builder, SSESpecification> {
        /**
         * <p>
         * Indicates whether server-side encryption is done using an Amazon Web Services managed key or an Amazon Web
         * Services owned key. If enabled (true), server-side encryption type is set to <code>KMS</code> and an Amazon
         * Web Services managed key is used (KMS charges apply). If disabled (false) or not specified, server-side
         * encryption is set to Amazon Web Services owned key.
         * </p>
         * 
         * @param enabled
         *        Indicates whether server-side encryption is done using an Amazon Web Services managed key or an Amazon
         *        Web Services owned key. If enabled (true), server-side encryption type is set to <code>KMS</code> and
         *        an Amazon Web Services managed key is used (KMS charges apply). If disabled (false) or not specified,
         *        server-side encryption is set to Amazon Web Services owned key.
         * @return Returns a reference to this object so that method calls can be chained together.
         */
        Builder enabled(Boolean enabled);

        /**
         * <p>
         * Server-side encryption type. The only supported value is:
         * </p>
         * <ul>
         * <li>
         * <p>
         * <code>KMS</code> - Server-side encryption that uses Key Management Service. The key is stored in your account
         * and is managed by KMS (KMS charges apply).
         * </p>
         * </li>
         * </ul>
         * 
         * @param sseType
         *        Server-side encryption type. The only supported value is:</p>
         *        <ul>
         *        <li>
         *        <p>
         *        <code>KMS</code> - Server-side encryption that uses Key Management Service. The key is stored in your
         *        account and is managed by KMS (KMS charges apply).
         *        </p>
         *        </li>
         * @see SSEType
         * @return Returns a reference to this object so that method calls can be chained together.
         * @see SSEType
         */
        Builder sseType(String sseType);

        /**
         * <p>
         * Server-side encryption type. The only supported value is:
         * </p>
         * <ul>
         * <li>
         * <p>
         * <code>KMS</code> - Server-side encryption that uses Key Management Service. The key is stored in your account
         * and is managed by KMS (KMS charges apply).
         * </p>
         * </li>
         * </ul>
         * 
         * @param sseType
         *        Server-side encryption type. The only supported value is:</p>
         *        <ul>
         *        <li>
         *        <p>
         *        <code>KMS</code> - Server-side encryption that uses Key Management Service. The key is stored in your
         *        account and is managed by KMS (KMS charges apply).
         *        </p>
         *        </li>
         * @see SSEType
         * @return Returns a reference to this object so that method calls can be chained together.
         * @see SSEType
         */
        Builder sseType(SSEType sseType);

        /**
         * <p>
         * The KMS key that should be used for the KMS encryption. To specify a key, use its key ID, Amazon Resource
         * Name (ARN), alias name, or alias ARN. Note that you should only provide this parameter if the key is
         * different from the default DynamoDB key <code>alias/aws/dynamodb</code>.
         * </p>
         * 
         * @param kmsMasterKeyId
         *        The KMS key that should be used for the KMS encryption. To specify a key, use its key ID, Amazon
         *        Resource Name (ARN), alias name, or alias ARN. Note that you should only provide this parameter if the
         *        key is different from the default DynamoDB key <code>alias/aws/dynamodb</code>.
         * @return Returns a reference to this object so that method calls can be chained together.
         */
        Builder kmsMasterKeyId(String kmsMasterKeyId);
    }

    static final class BuilderImpl implements Builder {
        private Boolean enabled;

        private String sseType;

        private String kmsMasterKeyId;

        private BuilderImpl() {
        }

        private BuilderImpl(SSESpecification model) {
            enabled(model.enabled);
            sseType(model.sseType);
            kmsMasterKeyId(model.kmsMasterKeyId);
        }

        public final Boolean getEnabled() {
            return enabled;
        }

        public final void setEnabled(Boolean enabled) {
            this.enabled = enabled;
        }

        @Override
        public final Builder enabled(Boolean enabled) {
            this.enabled = enabled;
            return this;
        }

        public final String getSseType() {
            return sseType;
        }

        public final void setSseType(String sseType) {
            this.sseType = sseType;
        }

        @Override
        public final Builder sseType(String sseType) {
            this.sseType = sseType;
            return this;
        }

        @Override
        public final Builder sseType(SSEType sseType) {
            this.sseType(sseType == null ? null : sseType.toString());
            return this;
        }

        public final String getKmsMasterKeyId() {
            return kmsMasterKeyId;
        }

        public final void setKmsMasterKeyId(String kmsMasterKeyId) {
            this.kmsMasterKeyId = kmsMasterKeyId;
        }

        @Override
        public final Builder kmsMasterKeyId(String kmsMasterKeyId) {
            this.kmsMasterKeyId = kmsMasterKeyId;
            return this;
        }

        @Override
        public SSESpecification build() {
            return new SSESpecification(this);
        }

        @Override
        public List<SdkField<?>> sdkFields() {
            return SDK_FIELDS;
        }
    }
}
