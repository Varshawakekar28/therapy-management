/*
 * Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
 * 
 * Licensed under the Apache License, Version 2.0 (the "License"). You may not use this file except in compliance with
 * the License. A copy of the License is located at
 * 
 * http://aws.amazon.com/apache2.0
 * 
 * or in the "license" file accompanying this file. This file is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR
 * CONDITIONS OF ANY KIND, either express or implied. See the License for the specific language governing permissions
 * and limitations under the License.
 */

package software.amazon.awssdk.services.dynamodb.model;

import java.io.Serializable;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.function.BiConsumer;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.stream.Collectors;
import java.util.stream.Stream;
import software.amazon.awssdk.annotations.Generated;
import software.amazon.awssdk.core.SdkField;
import software.amazon.awssdk.core.SdkPojo;
import software.amazon.awssdk.core.protocol.MarshallLocation;
import software.amazon.awssdk.core.protocol.MarshallingType;
import software.amazon.awssdk.core.traits.ListTrait;
import software.amazon.awssdk.core.traits.LocationTrait;
import software.amazon.awssdk.core.util.DefaultSdkAutoConstructList;
import software.amazon.awssdk.core.util.SdkAutoConstructList;
import software.amazon.awssdk.utils.ToString;
import software.amazon.awssdk.utils.builder.CopyableBuilder;
import software.amazon.awssdk.utils.builder.ToCopyableBuilder;

/**
 * <p>
 * Contains the details of the features enabled on the table when the backup was created. For example, LSIs, GSIs,
 * streams, TTL.
 * </p>
 */
@Generated("software.amazon.awssdk:codegen")
public final class SourceTableFeatureDetails implements SdkPojo, Serializable,
        ToCopyableBuilder<SourceTableFeatureDetails.Builder, SourceTableFeatureDetails> {
    private static final SdkField<List<LocalSecondaryIndexInfo>> LOCAL_SECONDARY_INDEXES_FIELD = SdkField
            .<List<LocalSecondaryIndexInfo>> builder(MarshallingType.LIST)
            .memberName("LocalSecondaryIndexes")
            .getter(getter(SourceTableFeatureDetails::localSecondaryIndexes))
            .setter(setter(Builder::localSecondaryIndexes))
            .traits(LocationTrait.builder().location(MarshallLocation.PAYLOAD).locationName("LocalSecondaryIndexes").build(),
                    ListTrait
                            .builder()
                            .memberLocationName(null)
                            .memberFieldInfo(
                                    SdkField.<LocalSecondaryIndexInfo> builder(MarshallingType.SDK_POJO)
                                            .constructor(LocalSecondaryIndexInfo::builder)
                                            .traits(LocationTrait.builder().location(MarshallLocation.PAYLOAD)
                                                    .locationName("member").build()).build()).build()).build();

    private static final SdkField<List<GlobalSecondaryIndexInfo>> GLOBAL_SECONDARY_INDEXES_FIELD = SdkField
            .<List<GlobalSecondaryIndexInfo>> builder(MarshallingType.LIST)
            .memberName("GlobalSecondaryIndexes")
            .getter(getter(SourceTableFeatureDetails::globalSecondaryIndexes))
            .setter(setter(Builder::globalSecondaryIndexes))
            .traits(LocationTrait.builder().location(MarshallLocation.PAYLOAD).locationName("GlobalSecondaryIndexes").build(),
                    ListTrait
                            .builder()
                            .memberLocationName(null)
                            .memberFieldInfo(
                                    SdkField.<GlobalSecondaryIndexInfo> builder(MarshallingType.SDK_POJO)
                                            .constructor(GlobalSecondaryIndexInfo::builder)
                                            .traits(LocationTrait.builder().location(MarshallLocation.PAYLOAD)
                                                    .locationName("member").build()).build()).build()).build();

    private static final SdkField<StreamSpecification> STREAM_DESCRIPTION_FIELD = SdkField
            .<StreamSpecification> builder(MarshallingType.SDK_POJO).memberName("StreamDescription")
            .getter(getter(SourceTableFeatureDetails::streamDescription)).setter(setter(Builder::streamDescription))
            .constructor(StreamSpecification::builder)
            .traits(LocationTrait.builder().location(MarshallLocation.PAYLOAD).locationName("StreamDescription").build()).build();

    private static final SdkField<TimeToLiveDescription> TIME_TO_LIVE_DESCRIPTION_FIELD = SdkField
            .<TimeToLiveDescription> builder(MarshallingType.SDK_POJO).memberName("TimeToLiveDescription")
            .getter(getter(SourceTableFeatureDetails::timeToLiveDescription)).setter(setter(Builder::timeToLiveDescription))
            .constructor(TimeToLiveDescription::builder)
            .traits(LocationTrait.builder().location(MarshallLocation.PAYLOAD).locationName("TimeToLiveDescription").build())
            .build();

    private static final SdkField<SSEDescription> SSE_DESCRIPTION_FIELD = SdkField
            .<SSEDescription> builder(MarshallingType.SDK_POJO).memberName("SSEDescription")
            .getter(getter(SourceTableFeatureDetails::sseDescription)).setter(setter(Builder::sseDescription))
            .constructor(SSEDescription::builder)
            .traits(LocationTrait.builder().location(MarshallLocation.PAYLOAD).locationName("SSEDescription").build()).build();

    private static final List<SdkField<?>> SDK_FIELDS = Collections.unmodifiableList(Arrays.asList(LOCAL_SECONDARY_INDEXES_FIELD,
            GLOBAL_SECONDARY_INDEXES_FIELD, STREAM_DESCRIPTION_FIELD, TIME_TO_LIVE_DESCRIPTION_FIELD, SSE_DESCRIPTION_FIELD));

    private static final long serialVersionUID = 1L;

    private final List<LocalSecondaryIndexInfo> localSecondaryIndexes;

    private final List<GlobalSecondaryIndexInfo> globalSecondaryIndexes;

    private final StreamSpecification streamDescription;

    private final TimeToLiveDescription timeToLiveDescription;

    private final SSEDescription sseDescription;

    private SourceTableFeatureDetails(BuilderImpl builder) {
        this.localSecondaryIndexes = builder.localSecondaryIndexes;
        this.globalSecondaryIndexes = builder.globalSecondaryIndexes;
        this.streamDescription = builder.streamDescription;
        this.timeToLiveDescription = builder.timeToLiveDescription;
        this.sseDescription = builder.sseDescription;
    }

    /**
     * For responses, this returns true if the service returned a value for the LocalSecondaryIndexes property. This
     * DOES NOT check that the value is non-empty (for which, you should check the {@code isEmpty()} method on the
     * property). This is useful because the SDK will never return a null collection or map, but you may need to
     * differentiate between the service returning nothing (or null) and the service returning an empty collection or
     * map. For requests, this returns true if a value for the property was specified in the request builder, and false
     * if a value was not specified.
     */
    public final boolean hasLocalSecondaryIndexes() {
        return localSecondaryIndexes != null && !(localSecondaryIndexes instanceof SdkAutoConstructList);
    }

    /**
     * <p>
     * Represents the LSI properties for the table when the backup was created. It includes the IndexName, KeySchema and
     * Projection for the LSIs on the table at the time of backup.
     * </p>
     * <p>
     * Attempts to modify the collection returned by this method will result in an UnsupportedOperationException.
     * </p>
     * <p>
     * This method will never return null. If you would like to know whether the service returned this field (so that
     * you can differentiate between null and empty), you can use the {@link #hasLocalSecondaryIndexes} method.
     * </p>
     * 
     * @return Represents the LSI properties for the table when the backup was created. It includes the IndexName,
     *         KeySchema and Projection for the LSIs on the table at the time of backup.
     */
    public final List<LocalSecondaryIndexInfo> localSecondaryIndexes() {
        return localSecondaryIndexes;
    }

    /**
     * For responses, this returns true if the service returned a value for the GlobalSecondaryIndexes property. This
     * DOES NOT check that the value is non-empty (for which, you should check the {@code isEmpty()} method on the
     * property). This is useful because the SDK will never return a null collection or map, but you may need to
     * differentiate between the service returning nothing (or null) and the service returning an empty collection or
     * map. For requests, this returns true if a value for the property was specified in the request builder, and false
     * if a value was not specified.
     */
    public final boolean hasGlobalSecondaryIndexes() {
        return globalSecondaryIndexes != null && !(globalSecondaryIndexes instanceof SdkAutoConstructList);
    }

    /**
     * <p>
     * Represents the GSI properties for the table when the backup was created. It includes the IndexName, KeySchema,
     * Projection, and ProvisionedThroughput for the GSIs on the table at the time of backup.
     * </p>
     * <p>
     * Attempts to modify the collection returned by this method will result in an UnsupportedOperationException.
     * </p>
     * <p>
     * This method will never return null. If you would like to know whether the service returned this field (so that
     * you can differentiate between null and empty), you can use the {@link #hasGlobalSecondaryIndexes} method.
     * </p>
     * 
     * @return Represents the GSI properties for the table when the backup was created. It includes the IndexName,
     *         KeySchema, Projection, and ProvisionedThroughput for the GSIs on the table at the time of backup.
     */
    public final List<GlobalSecondaryIndexInfo> globalSecondaryIndexes() {
        return globalSecondaryIndexes;
    }

    /**
     * <p>
     * Stream settings on the table when the backup was created.
     * </p>
     * 
     * @return Stream settings on the table when the backup was created.
     */
    public final StreamSpecification streamDescription() {
        return streamDescription;
    }

    /**
     * <p>
     * Time to Live settings on the table when the backup was created.
     * </p>
     * 
     * @return Time to Live settings on the table when the backup was created.
     */
    public final TimeToLiveDescription timeToLiveDescription() {
        return timeToLiveDescription;
    }

    /**
     * <p>
     * The description of the server-side encryption status on the table when the backup was created.
     * </p>
     * 
     * @return The description of the server-side encryption status on the table when the backup was created.
     */
    public final SSEDescription sseDescription() {
        return sseDescription;
    }

    @Override
    public Builder toBuilder() {
        return new BuilderImpl(this);
    }

    public static Builder builder() {
        return new BuilderImpl();
    }

    public static Class<? extends Builder> serializableBuilderClass() {
        return BuilderImpl.class;
    }

    @Override
    public final int hashCode() {
        int hashCode = 1;
        hashCode = 31 * hashCode + Objects.hashCode(hasLocalSecondaryIndexes() ? localSecondaryIndexes() : null);
        hashCode = 31 * hashCode + Objects.hashCode(hasGlobalSecondaryIndexes() ? globalSecondaryIndexes() : null);
        hashCode = 31 * hashCode + Objects.hashCode(streamDescription());
        hashCode = 31 * hashCode + Objects.hashCode(timeToLiveDescription());
        hashCode = 31 * hashCode + Objects.hashCode(sseDescription());
        return hashCode;
    }

    @Override
    public final boolean equals(Object obj) {
        return equalsBySdkFields(obj);
    }

    @Override
    public final boolean equalsBySdkFields(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (!(obj instanceof SourceTableFeatureDetails)) {
            return false;
        }
        SourceTableFeatureDetails other = (SourceTableFeatureDetails) obj;
        return hasLocalSecondaryIndexes() == other.hasLocalSecondaryIndexes()
                && Objects.equals(localSecondaryIndexes(), other.localSecondaryIndexes())
                && hasGlobalSecondaryIndexes() == other.hasGlobalSecondaryIndexes()
                && Objects.equals(globalSecondaryIndexes(), other.globalSecondaryIndexes())
                && Objects.equals(streamDescription(), other.streamDescription())
                && Objects.equals(timeToLiveDescription(), other.timeToLiveDescription())
                && Objects.equals(sseDescription(), other.sseDescription());
    }

    /**
     * Returns a string representation of this object. This is useful for testing and debugging. Sensitive data will be
     * redacted from this string using a placeholder value.
     */
    @Override
    public final String toString() {
        return ToString.builder("SourceTableFeatureDetails")
                .add("LocalSecondaryIndexes", hasLocalSecondaryIndexes() ? localSecondaryIndexes() : null)
                .add("GlobalSecondaryIndexes", hasGlobalSecondaryIndexes() ? globalSecondaryIndexes() : null)
                .add("StreamDescription", streamDescription()).add("TimeToLiveDescription", timeToLiveDescription())
                .add("SSEDescription", sseDescription()).build();
    }

    public final <T> Optional<T> getValueForField(String fieldName, Class<T> clazz) {
        switch (fieldName) {
        case "LocalSecondaryIndexes":
            return Optional.ofNullable(clazz.cast(localSecondaryIndexes()));
        case "GlobalSecondaryIndexes":
            return Optional.ofNullable(clazz.cast(globalSecondaryIndexes()));
        case "StreamDescription":
            return Optional.ofNullable(clazz.cast(streamDescription()));
        case "TimeToLiveDescription":
            return Optional.ofNullable(clazz.cast(timeToLiveDescription()));
        case "SSEDescription":
            return Optional.ofNullable(clazz.cast(sseDescription()));
        default:
            return Optional.empty();
        }
    }

    @Override
    public final List<SdkField<?>> sdkFields() {
        return SDK_FIELDS;
    }

    private static <T> Function<Object, T> getter(Function<SourceTableFeatureDetails, T> g) {
        return obj -> g.apply((SourceTableFeatureDetails) obj);
    }

    private static <T> BiConsumer<Object, T> setter(BiConsumer<Builder, T> s) {
        return (obj, val) -> s.accept((Builder) obj, val);
    }

    public interface Builder extends SdkPojo, CopyableBuilder<Builder, SourceTableFeatureDetails> {
        /**
         * <p>
         * Represents the LSI properties for the table when the backup was created. It includes the IndexName, KeySchema
         * and Projection for the LSIs on the table at the time of backup.
         * </p>
         * 
         * @param localSecondaryIndexes
         *        Represents the LSI properties for the table when the backup was created. It includes the IndexName,
         *        KeySchema and Projection for the LSIs on the table at the time of backup.
         * @return Returns a reference to this object so that method calls can be chained together.
         */
        Builder localSecondaryIndexes(Collection<LocalSecondaryIndexInfo> localSecondaryIndexes);

        /**
         * <p>
         * Represents the LSI properties for the table when the backup was created. It includes the IndexName, KeySchema
         * and Projection for the LSIs on the table at the time of backup.
         * </p>
         * 
         * @param localSecondaryIndexes
         *        Represents the LSI properties for the table when the backup was created. It includes the IndexName,
         *        KeySchema and Projection for the LSIs on the table at the time of backup.
         * @return Returns a reference to this object so that method calls can be chained together.
         */
        Builder localSecondaryIndexes(LocalSecondaryIndexInfo... localSecondaryIndexes);

        /**
         * <p>
         * Represents the LSI properties for the table when the backup was created. It includes the IndexName, KeySchema
         * and Projection for the LSIs on the table at the time of backup.
         * </p>
         * This is a convenience method that creates an instance of the
         * {@link software.amazon.awssdk.services.dynamodb.model.LocalSecondaryIndexInfo.Builder} avoiding the need to
         * create one manually via
         * {@link software.amazon.awssdk.services.dynamodb.model.LocalSecondaryIndexInfo#builder()}.
         *
         * <p>
         * When the {@link Consumer} completes,
         * {@link software.amazon.awssdk.services.dynamodb.model.LocalSecondaryIndexInfo.Builder#build()} is called
         * immediately and its result is passed to {@link #localSecondaryIndexes(List<LocalSecondaryIndexInfo>)}.
         * 
         * @param localSecondaryIndexes
         *        a consumer that will call methods on
         *        {@link software.amazon.awssdk.services.dynamodb.model.LocalSecondaryIndexInfo.Builder}
         * @return Returns a reference to this object so that method calls can be chained together.
         * @see #localSecondaryIndexes(java.util.Collection<LocalSecondaryIndexInfo>)
         */
        Builder localSecondaryIndexes(Consumer<LocalSecondaryIndexInfo.Builder>... localSecondaryIndexes);

        /**
         * <p>
         * Represents the GSI properties for the table when the backup was created. It includes the IndexName,
         * KeySchema, Projection, and ProvisionedThroughput for the GSIs on the table at the time of backup.
         * </p>
         * 
         * @param globalSecondaryIndexes
         *        Represents the GSI properties for the table when the backup was created. It includes the IndexName,
         *        KeySchema, Projection, and ProvisionedThroughput for the GSIs on the table at the time of backup.
         * @return Returns a reference to this object so that method calls can be chained together.
         */
        Builder globalSecondaryIndexes(Collection<GlobalSecondaryIndexInfo> globalSecondaryIndexes);

        /**
         * <p>
         * Represents the GSI properties for the table when the backup was created. It includes the IndexName,
         * KeySchema, Projection, and ProvisionedThroughput for the GSIs on the table at the time of backup.
         * </p>
         * 
         * @param globalSecondaryIndexes
         *        Represents the GSI properties for the table when the backup was created. It includes the IndexName,
         *        KeySchema, Projection, and ProvisionedThroughput for the GSIs on the table at the time of backup.
         * @return Returns a reference to this object so that method calls can be chained together.
         */
        Builder globalSecondaryIndexes(GlobalSecondaryIndexInfo... globalSecondaryIndexes);

        /**
         * <p>
         * Represents the GSI properties for the table when the backup was created. It includes the IndexName,
         * KeySchema, Projection, and ProvisionedThroughput for the GSIs on the table at the time of backup.
         * </p>
         * This is a convenience method that creates an instance of the
         * {@link software.amazon.awssdk.services.dynamodb.model.GlobalSecondaryIndexInfo.Builder} avoiding the need to
         * create one manually via
         * {@link software.amazon.awssdk.services.dynamodb.model.GlobalSecondaryIndexInfo#builder()}.
         *
         * <p>
         * When the {@link Consumer} completes,
         * {@link software.amazon.awssdk.services.dynamodb.model.GlobalSecondaryIndexInfo.Builder#build()} is called
         * immediately and its result is passed to {@link #globalSecondaryIndexes(List<GlobalSecondaryIndexInfo>)}.
         * 
         * @param globalSecondaryIndexes
         *        a consumer that will call methods on
         *        {@link software.amazon.awssdk.services.dynamodb.model.GlobalSecondaryIndexInfo.Builder}
         * @return Returns a reference to this object so that method calls can be chained together.
         * @see #globalSecondaryIndexes(java.util.Collection<GlobalSecondaryIndexInfo>)
         */
        Builder globalSecondaryIndexes(Consumer<GlobalSecondaryIndexInfo.Builder>... globalSecondaryIndexes);

        /**
         * <p>
         * Stream settings on the table when the backup was created.
         * </p>
         * 
         * @param streamDescription
         *        Stream settings on the table when the backup was created.
         * @return Returns a reference to this object so that method calls can be chained together.
         */
        Builder streamDescription(StreamSpecification streamDescription);

        /**
         * <p>
         * Stream settings on the table when the backup was created.
         * </p>
         * This is a convenience method that creates an instance of the {@link StreamSpecification.Builder} avoiding the
         * need to create one manually via {@link StreamSpecification#builder()}.
         *
         * <p>
         * When the {@link Consumer} completes, {@link StreamSpecification.Builder#build()} is called immediately and
         * its result is passed to {@link #streamDescription(StreamSpecification)}.
         * 
         * @param streamDescription
         *        a consumer that will call methods on {@link StreamSpecification.Builder}
         * @return Returns a reference to this object so that method calls can be chained together.
         * @see #streamDescription(StreamSpecification)
         */
        default Builder streamDescription(Consumer<StreamSpecification.Builder> streamDescription) {
            return streamDescription(StreamSpecification.builder().applyMutation(streamDescription).build());
        }

        /**
         * <p>
         * Time to Live settings on the table when the backup was created.
         * </p>
         * 
         * @param timeToLiveDescription
         *        Time to Live settings on the table when the backup was created.
         * @return Returns a reference to this object so that method calls can be chained together.
         */
        Builder timeToLiveDescription(TimeToLiveDescription timeToLiveDescription);

        /**
         * <p>
         * Time to Live settings on the table when the backup was created.
         * </p>
         * This is a convenience method that creates an instance of the {@link TimeToLiveDescription.Builder} avoiding
         * the need to create one manually via {@link TimeToLiveDescription#builder()}.
         *
         * <p>
         * When the {@link Consumer} completes, {@link TimeToLiveDescription.Builder#build()} is called immediately and
         * its result is passed to {@link #timeToLiveDescription(TimeToLiveDescription)}.
         * 
         * @param timeToLiveDescription
         *        a consumer that will call methods on {@link TimeToLiveDescription.Builder}
         * @return Returns a reference to this object so that method calls can be chained together.
         * @see #timeToLiveDescription(TimeToLiveDescription)
         */
        default Builder timeToLiveDescription(Consumer<TimeToLiveDescription.Builder> timeToLiveDescription) {
            return timeToLiveDescription(TimeToLiveDescription.builder().applyMutation(timeToLiveDescription).build());
        }

        /**
         * <p>
         * The description of the server-side encryption status on the table when the backup was created.
         * </p>
         * 
         * @param sseDescription
         *        The description of the server-side encryption status on the table when the backup was created.
         * @return Returns a reference to this object so that method calls can be chained together.
         */
        Builder sseDescription(SSEDescription sseDescription);

        /**
         * <p>
         * The description of the server-side encryption status on the table when the backup was created.
         * </p>
         * This is a convenience method that creates an instance of the {@link SSEDescription.Builder} avoiding the need
         * to create one manually via {@link SSEDescription#builder()}.
         *
         * <p>
         * When the {@link Consumer} completes, {@link SSEDescription.Builder#build()} is called immediately and its
         * result is passed to {@link #sseDescription(SSEDescription)}.
         * 
         * @param sseDescription
         *        a consumer that will call methods on {@link SSEDescription.Builder}
         * @return Returns a reference to this object so that method calls can be chained together.
         * @see #sseDescription(SSEDescription)
         */
        default Builder sseDescription(Consumer<SSEDescription.Builder> sseDescription) {
            return sseDescription(SSEDescription.builder().applyMutation(sseDescription).build());
        }
    }

    static final class BuilderImpl implements Builder {
        private List<LocalSecondaryIndexInfo> localSecondaryIndexes = DefaultSdkAutoConstructList.getInstance();

        private List<GlobalSecondaryIndexInfo> globalSecondaryIndexes = DefaultSdkAutoConstructList.getInstance();

        private StreamSpecification streamDescription;

        private TimeToLiveDescription timeToLiveDescription;

        private SSEDescription sseDescription;

        private BuilderImpl() {
        }

        private BuilderImpl(SourceTableFeatureDetails model) {
            localSecondaryIndexes(model.localSecondaryIndexes);
            globalSecondaryIndexes(model.globalSecondaryIndexes);
            streamDescription(model.streamDescription);
            timeToLiveDescription(model.timeToLiveDescription);
            sseDescription(model.sseDescription);
        }

        public final List<LocalSecondaryIndexInfo.Builder> getLocalSecondaryIndexes() {
            List<LocalSecondaryIndexInfo.Builder> result = LocalSecondaryIndexesCopier.copyToBuilder(this.localSecondaryIndexes);
            if (result instanceof SdkAutoConstructList) {
                return null;
            }
            return result;
        }

        public final void setLocalSecondaryIndexes(Collection<LocalSecondaryIndexInfo.BuilderImpl> localSecondaryIndexes) {
            this.localSecondaryIndexes = LocalSecondaryIndexesCopier.copyFromBuilder(localSecondaryIndexes);
        }

        @Override
        public final Builder localSecondaryIndexes(Collection<LocalSecondaryIndexInfo> localSecondaryIndexes) {
            this.localSecondaryIndexes = LocalSecondaryIndexesCopier.copy(localSecondaryIndexes);
            return this;
        }

        @Override
        @SafeVarargs
        public final Builder localSecondaryIndexes(LocalSecondaryIndexInfo... localSecondaryIndexes) {
            localSecondaryIndexes(Arrays.asList(localSecondaryIndexes));
            return this;
        }

        @Override
        @SafeVarargs
        public final Builder localSecondaryIndexes(Consumer<LocalSecondaryIndexInfo.Builder>... localSecondaryIndexes) {
            localSecondaryIndexes(Stream.of(localSecondaryIndexes)
                    .map(c -> LocalSecondaryIndexInfo.builder().applyMutation(c).build()).collect(Collectors.toList()));
            return this;
        }

        public final List<GlobalSecondaryIndexInfo.Builder> getGlobalSecondaryIndexes() {
            List<GlobalSecondaryIndexInfo.Builder> result = GlobalSecondaryIndexesCopier
                    .copyToBuilder(this.globalSecondaryIndexes);
            if (result instanceof SdkAutoConstructList) {
                return null;
            }
            return result;
        }

        public final void setGlobalSecondaryIndexes(Collection<GlobalSecondaryIndexInfo.BuilderImpl> globalSecondaryIndexes) {
            this.globalSecondaryIndexes = GlobalSecondaryIndexesCopier.copyFromBuilder(globalSecondaryIndexes);
        }

        @Override
        public final Builder globalSecondaryIndexes(Collection<GlobalSecondaryIndexInfo> globalSecondaryIndexes) {
            this.globalSecondaryIndexes = GlobalSecondaryIndexesCopier.copy(globalSecondaryIndexes);
            return this;
        }

        @Override
        @SafeVarargs
        public final Builder globalSecondaryIndexes(GlobalSecondaryIndexInfo... globalSecondaryIndexes) {
            globalSecondaryIndexes(Arrays.asList(globalSecondaryIndexes));
            return this;
        }

        @Override
        @SafeVarargs
        public final Builder globalSecondaryIndexes(Consumer<GlobalSecondaryIndexInfo.Builder>... globalSecondaryIndexes) {
            globalSecondaryIndexes(Stream.of(globalSecondaryIndexes)
                    .map(c -> GlobalSecondaryIndexInfo.builder().applyMutation(c).build()).collect(Collectors.toList()));
            return this;
        }

        public final StreamSpecification.Builder getStreamDescription() {
            return streamDescription != null ? streamDescription.toBuilder() : null;
        }

        public final void setStreamDescription(StreamSpecification.BuilderImpl streamDescription) {
            this.streamDescription = streamDescription != null ? streamDescription.build() : null;
        }

        @Override
        public final Builder streamDescription(StreamSpecification streamDescription) {
            this.streamDescription = streamDescription;
            return this;
        }

        public final TimeToLiveDescription.Builder getTimeToLiveDescription() {
            return timeToLiveDescription != null ? timeToLiveDescription.toBuilder() : null;
        }

        public final void setTimeToLiveDescription(TimeToLiveDescription.BuilderImpl timeToLiveDescription) {
            this.timeToLiveDescription = timeToLiveDescription != null ? timeToLiveDescription.build() : null;
        }

        @Override
        public final Builder timeToLiveDescription(TimeToLiveDescription timeToLiveDescription) {
            this.timeToLiveDescription = timeToLiveDescription;
            return this;
        }

        public final SSEDescription.Builder getSseDescription() {
            return sseDescription != null ? sseDescription.toBuilder() : null;
        }

        public final void setSseDescription(SSEDescription.BuilderImpl sseDescription) {
            this.sseDescription = sseDescription != null ? sseDescription.build() : null;
        }

        @Override
        public final Builder sseDescription(SSEDescription sseDescription) {
            this.sseDescription = sseDescription;
            return this;
        }

        @Override
        public SourceTableFeatureDetails build() {
            return new SourceTableFeatureDetails(this);
        }

        @Override
        public List<SdkField<?>> sdkFields() {
            return SDK_FIELDS;
        }
    }
}
