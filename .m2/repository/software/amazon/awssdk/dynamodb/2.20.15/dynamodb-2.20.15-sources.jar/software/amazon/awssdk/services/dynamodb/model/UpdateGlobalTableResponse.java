/*
 * Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
 * 
 * Licensed under the Apache License, Version 2.0 (the "License"). You may not use this file except in compliance with
 * the License. A copy of the License is located at
 * 
 * http://aws.amazon.com/apache2.0
 * 
 * or in the "license" file accompanying this file. This file is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR
 * CONDITIONS OF ANY KIND, either express or implied. See the License for the specific language governing permissions
 * and limitations under the License.
 */

package software.amazon.awssdk.services.dynamodb.model;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.function.BiConsumer;
import java.util.function.Consumer;
import java.util.function.Function;
import software.amazon.awssdk.annotations.Generated;
import software.amazon.awssdk.core.SdkField;
import software.amazon.awssdk.core.SdkPojo;
import software.amazon.awssdk.core.protocol.MarshallLocation;
import software.amazon.awssdk.core.protocol.MarshallingType;
import software.amazon.awssdk.core.traits.LocationTrait;
import software.amazon.awssdk.utils.ToString;
import software.amazon.awssdk.utils.builder.CopyableBuilder;
import software.amazon.awssdk.utils.builder.ToCopyableBuilder;

/**
 */
@Generated("software.amazon.awssdk:codegen")
public final class UpdateGlobalTableResponse extends DynamoDbResponse implements
        ToCopyableBuilder<UpdateGlobalTableResponse.Builder, UpdateGlobalTableResponse> {
    private static final SdkField<GlobalTableDescription> GLOBAL_TABLE_DESCRIPTION_FIELD = SdkField
            .<GlobalTableDescription> builder(MarshallingType.SDK_POJO).memberName("GlobalTableDescription")
            .getter(getter(UpdateGlobalTableResponse::globalTableDescription)).setter(setter(Builder::globalTableDescription))
            .constructor(GlobalTableDescription::builder)
            .traits(LocationTrait.builder().location(MarshallLocation.PAYLOAD).locationName("GlobalTableDescription").build())
            .build();

    private static final List<SdkField<?>> SDK_FIELDS = Collections.unmodifiableList(Arrays
            .asList(GLOBAL_TABLE_DESCRIPTION_FIELD));

    private final GlobalTableDescription globalTableDescription;

    private UpdateGlobalTableResponse(BuilderImpl builder) {
        super(builder);
        this.globalTableDescription = builder.globalTableDescription;
    }

    /**
     * <p>
     * Contains the details of the global table.
     * </p>
     * 
     * @return Contains the details of the global table.
     */
    public final GlobalTableDescription globalTableDescription() {
        return globalTableDescription;
    }

    @Override
    public Builder toBuilder() {
        return new BuilderImpl(this);
    }

    public static Builder builder() {
        return new BuilderImpl();
    }

    public static Class<? extends Builder> serializableBuilderClass() {
        return BuilderImpl.class;
    }

    @Override
    public final int hashCode() {
        int hashCode = 1;
        hashCode = 31 * hashCode + super.hashCode();
        hashCode = 31 * hashCode + Objects.hashCode(globalTableDescription());
        return hashCode;
    }

    @Override
    public final boolean equals(Object obj) {
        return super.equals(obj) && equalsBySdkFields(obj);
    }

    @Override
    public final boolean equalsBySdkFields(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (!(obj instanceof UpdateGlobalTableResponse)) {
            return false;
        }
        UpdateGlobalTableResponse other = (UpdateGlobalTableResponse) obj;
        return Objects.equals(globalTableDescription(), other.globalTableDescription());
    }

    /**
     * Returns a string representation of this object. This is useful for testing and debugging. Sensitive data will be
     * redacted from this string using a placeholder value.
     */
    @Override
    public final String toString() {
        return ToString.builder("UpdateGlobalTableResponse").add("GlobalTableDescription", globalTableDescription()).build();
    }

    public final <T> Optional<T> getValueForField(String fieldName, Class<T> clazz) {
        switch (fieldName) {
        case "GlobalTableDescription":
            return Optional.ofNullable(clazz.cast(globalTableDescription()));
        default:
            return Optional.empty();
        }
    }

    @Override
    public final List<SdkField<?>> sdkFields() {
        return SDK_FIELDS;
    }

    private static <T> Function<Object, T> getter(Function<UpdateGlobalTableResponse, T> g) {
        return obj -> g.apply((UpdateGlobalTableResponse) obj);
    }

    private static <T> BiConsumer<Object, T> setter(BiConsumer<Builder, T> s) {
        return (obj, val) -> s.accept((Builder) obj, val);
    }

    public interface Builder extends DynamoDbResponse.Builder, SdkPojo, CopyableBuilder<Builder, UpdateGlobalTableResponse> {
        /**
         * <p>
         * Contains the details of the global table.
         * </p>
         * 
         * @param globalTableDescription
         *        Contains the details of the global table.
         * @return Returns a reference to this object so that method calls can be chained together.
         */
        Builder globalTableDescription(GlobalTableDescription globalTableDescription);

        /**
         * <p>
         * Contains the details of the global table.
         * </p>
         * This is a convenience method that creates an instance of the {@link GlobalTableDescription.Builder} avoiding
         * the need to create one manually via {@link GlobalTableDescription#builder()}.
         *
         * <p>
         * When the {@link Consumer} completes, {@link GlobalTableDescription.Builder#build()} is called immediately and
         * its result is passed to {@link #globalTableDescription(GlobalTableDescription)}.
         * 
         * @param globalTableDescription
         *        a consumer that will call methods on {@link GlobalTableDescription.Builder}
         * @return Returns a reference to this object so that method calls can be chained together.
         * @see #globalTableDescription(GlobalTableDescription)
         */
        default Builder globalTableDescription(Consumer<GlobalTableDescription.Builder> globalTableDescription) {
            return globalTableDescription(GlobalTableDescription.builder().applyMutation(globalTableDescription).build());
        }
    }

    static final class BuilderImpl extends DynamoDbResponse.BuilderImpl implements Builder {
        private GlobalTableDescription globalTableDescription;

        private BuilderImpl() {
        }

        private BuilderImpl(UpdateGlobalTableResponse model) {
            super(model);
            globalTableDescription(model.globalTableDescription);
        }

        public final GlobalTableDescription.Builder getGlobalTableDescription() {
            return globalTableDescription != null ? globalTableDescription.toBuilder() : null;
        }

        public final void setGlobalTableDescription(GlobalTableDescription.BuilderImpl globalTableDescription) {
            this.globalTableDescription = globalTableDescription != null ? globalTableDescription.build() : null;
        }

        @Override
        public final Builder globalTableDescription(GlobalTableDescription globalTableDescription) {
            this.globalTableDescription = globalTableDescription;
            return this;
        }

        @Override
        public UpdateGlobalTableResponse build() {
            return new UpdateGlobalTableResponse(this);
        }

        @Override
        public List<SdkField<?>> sdkFields() {
            return SDK_FIELDS;
        }
    }
}
