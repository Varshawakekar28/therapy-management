/*
 * Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
 * 
 * Licensed under the Apache License, Version 2.0 (the "License"). You may not use this file except in compliance with
 * the License. A copy of the License is located at
 * 
 * http://aws.amazon.com/apache2.0
 * 
 * or in the "license" file accompanying this file. This file is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR
 * CONDITIONS OF ANY KIND, either express or implied. See the License for the specific language governing permissions
 * and limitations under the License.
 */

package software.amazon.awssdk.services.dynamodb.model;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.function.BiConsumer;
import java.util.function.Consumer;
import java.util.function.Function;
import software.amazon.awssdk.annotations.Generated;
import software.amazon.awssdk.core.SdkField;
import software.amazon.awssdk.core.SdkPojo;
import software.amazon.awssdk.core.protocol.MarshallLocation;
import software.amazon.awssdk.core.protocol.MarshallingType;
import software.amazon.awssdk.core.traits.LocationTrait;
import software.amazon.awssdk.utils.ToString;
import software.amazon.awssdk.utils.builder.CopyableBuilder;
import software.amazon.awssdk.utils.builder.ToCopyableBuilder;

/**
 */
@Generated("software.amazon.awssdk:codegen")
public final class UpdateTimeToLiveResponse extends DynamoDbResponse implements
        ToCopyableBuilder<UpdateTimeToLiveResponse.Builder, UpdateTimeToLiveResponse> {
    private static final SdkField<TimeToLiveSpecification> TIME_TO_LIVE_SPECIFICATION_FIELD = SdkField
            .<TimeToLiveSpecification> builder(MarshallingType.SDK_POJO).memberName("TimeToLiveSpecification")
            .getter(getter(UpdateTimeToLiveResponse::timeToLiveSpecification)).setter(setter(Builder::timeToLiveSpecification))
            .constructor(TimeToLiveSpecification::builder)
            .traits(LocationTrait.builder().location(MarshallLocation.PAYLOAD).locationName("TimeToLiveSpecification").build())
            .build();

    private static final List<SdkField<?>> SDK_FIELDS = Collections.unmodifiableList(Arrays
            .asList(TIME_TO_LIVE_SPECIFICATION_FIELD));

    private final TimeToLiveSpecification timeToLiveSpecification;

    private UpdateTimeToLiveResponse(BuilderImpl builder) {
        super(builder);
        this.timeToLiveSpecification = builder.timeToLiveSpecification;
    }

    /**
     * <p>
     * Represents the output of an <code>UpdateTimeToLive</code> operation.
     * </p>
     * 
     * @return Represents the output of an <code>UpdateTimeToLive</code> operation.
     */
    public final TimeToLiveSpecification timeToLiveSpecification() {
        return timeToLiveSpecification;
    }

    @Override
    public Builder toBuilder() {
        return new BuilderImpl(this);
    }

    public static Builder builder() {
        return new BuilderImpl();
    }

    public static Class<? extends Builder> serializableBuilderClass() {
        return BuilderImpl.class;
    }

    @Override
    public final int hashCode() {
        int hashCode = 1;
        hashCode = 31 * hashCode + super.hashCode();
        hashCode = 31 * hashCode + Objects.hashCode(timeToLiveSpecification());
        return hashCode;
    }

    @Override
    public final boolean equals(Object obj) {
        return super.equals(obj) && equalsBySdkFields(obj);
    }

    @Override
    public final boolean equalsBySdkFields(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (!(obj instanceof UpdateTimeToLiveResponse)) {
            return false;
        }
        UpdateTimeToLiveResponse other = (UpdateTimeToLiveResponse) obj;
        return Objects.equals(timeToLiveSpecification(), other.timeToLiveSpecification());
    }

    /**
     * Returns a string representation of this object. This is useful for testing and debugging. Sensitive data will be
     * redacted from this string using a placeholder value.
     */
    @Override
    public final String toString() {
        return ToString.builder("UpdateTimeToLiveResponse").add("TimeToLiveSpecification", timeToLiveSpecification()).build();
    }

    public final <T> Optional<T> getValueForField(String fieldName, Class<T> clazz) {
        switch (fieldName) {
        case "TimeToLiveSpecification":
            return Optional.ofNullable(clazz.cast(timeToLiveSpecification()));
        default:
            return Optional.empty();
        }
    }

    @Override
    public final List<SdkField<?>> sdkFields() {
        return SDK_FIELDS;
    }

    private static <T> Function<Object, T> getter(Function<UpdateTimeToLiveResponse, T> g) {
        return obj -> g.apply((UpdateTimeToLiveResponse) obj);
    }

    private static <T> BiConsumer<Object, T> setter(BiConsumer<Builder, T> s) {
        return (obj, val) -> s.accept((Builder) obj, val);
    }

    public interface Builder extends DynamoDbResponse.Builder, SdkPojo, CopyableBuilder<Builder, UpdateTimeToLiveResponse> {
        /**
         * <p>
         * Represents the output of an <code>UpdateTimeToLive</code> operation.
         * </p>
         * 
         * @param timeToLiveSpecification
         *        Represents the output of an <code>UpdateTimeToLive</code> operation.
         * @return Returns a reference to this object so that method calls can be chained together.
         */
        Builder timeToLiveSpecification(TimeToLiveSpecification timeToLiveSpecification);

        /**
         * <p>
         * Represents the output of an <code>UpdateTimeToLive</code> operation.
         * </p>
         * This is a convenience method that creates an instance of the {@link TimeToLiveSpecification.Builder} avoiding
         * the need to create one manually via {@link TimeToLiveSpecification#builder()}.
         *
         * <p>
         * When the {@link Consumer} completes, {@link TimeToLiveSpecification.Builder#build()} is called immediately
         * and its result is passed to {@link #timeToLiveSpecification(TimeToLiveSpecification)}.
         * 
         * @param timeToLiveSpecification
         *        a consumer that will call methods on {@link TimeToLiveSpecification.Builder}
         * @return Returns a reference to this object so that method calls can be chained together.
         * @see #timeToLiveSpecification(TimeToLiveSpecification)
         */
        default Builder timeToLiveSpecification(Consumer<TimeToLiveSpecification.Builder> timeToLiveSpecification) {
            return timeToLiveSpecification(TimeToLiveSpecification.builder().applyMutation(timeToLiveSpecification).build());
        }
    }

    static final class BuilderImpl extends DynamoDbResponse.BuilderImpl implements Builder {
        private TimeToLiveSpecification timeToLiveSpecification;

        private BuilderImpl() {
        }

        private BuilderImpl(UpdateTimeToLiveResponse model) {
            super(model);
            timeToLiveSpecification(model.timeToLiveSpecification);
        }

        public final TimeToLiveSpecification.Builder getTimeToLiveSpecification() {
            return timeToLiveSpecification != null ? timeToLiveSpecification.toBuilder() : null;
        }

        public final void setTimeToLiveSpecification(TimeToLiveSpecification.BuilderImpl timeToLiveSpecification) {
            this.timeToLiveSpecification = timeToLiveSpecification != null ? timeToLiveSpecification.build() : null;
        }

        @Override
        public final Builder timeToLiveSpecification(TimeToLiveSpecification timeToLiveSpecification) {
            this.timeToLiveSpecification = timeToLiveSpecification;
            return this;
        }

        @Override
        public UpdateTimeToLiveResponse build() {
            return new UpdateTimeToLiveResponse(this);
        }

        @Override
        public List<SdkField<?>> sdkFields() {
            return SDK_FIELDS;
        }
    }
}
