/*
 * Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
 * 
 * Licensed under the Apache License, Version 2.0 (the "License"). You may not use this file except in compliance with
 * the License. A copy of the License is located at
 * 
 * http://aws.amazon.com/apache2.0
 * 
 * or in the "license" file accompanying this file. This file is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR
 * CONDITIONS OF ANY KIND, either express or implied. See the License for the specific language governing permissions
 * and limitations under the License.
 */

package software.amazon.awssdk.services.dynamodb.model;

import java.io.Serializable;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.function.BiConsumer;
import java.util.function.Consumer;
import java.util.function.Function;
import software.amazon.awssdk.annotations.Generated;
import software.amazon.awssdk.core.SdkField;
import software.amazon.awssdk.core.SdkPojo;
import software.amazon.awssdk.core.protocol.MarshallLocation;
import software.amazon.awssdk.core.protocol.MarshallingType;
import software.amazon.awssdk.core.traits.LocationTrait;
import software.amazon.awssdk.utils.ToString;
import software.amazon.awssdk.utils.builder.CopyableBuilder;
import software.amazon.awssdk.utils.builder.ToCopyableBuilder;

/**
 * <p>
 * Represents an operation to perform - either <code>DeleteItem</code> or <code>PutItem</code>. You can only request one
 * of these operations, not both, in a single <code>WriteRequest</code>. If you do need to perform both of these
 * operations, you need to provide two separate <code>WriteRequest</code> objects.
 * </p>
 */
@Generated("software.amazon.awssdk:codegen")
public final class WriteRequest implements SdkPojo, Serializable, ToCopyableBuilder<WriteRequest.Builder, WriteRequest> {
    private static final SdkField<PutRequest> PUT_REQUEST_FIELD = SdkField.<PutRequest> builder(MarshallingType.SDK_POJO)
            .memberName("PutRequest").getter(getter(WriteRequest::putRequest)).setter(setter(Builder::putRequest))
            .constructor(PutRequest::builder)
            .traits(LocationTrait.builder().location(MarshallLocation.PAYLOAD).locationName("PutRequest").build()).build();

    private static final SdkField<DeleteRequest> DELETE_REQUEST_FIELD = SdkField
            .<DeleteRequest> builder(MarshallingType.SDK_POJO).memberName("DeleteRequest")
            .getter(getter(WriteRequest::deleteRequest)).setter(setter(Builder::deleteRequest))
            .constructor(DeleteRequest::builder)
            .traits(LocationTrait.builder().location(MarshallLocation.PAYLOAD).locationName("DeleteRequest").build()).build();

    private static final List<SdkField<?>> SDK_FIELDS = Collections.unmodifiableList(Arrays.asList(PUT_REQUEST_FIELD,
            DELETE_REQUEST_FIELD));

    private static final long serialVersionUID = 1L;

    private final PutRequest putRequest;

    private final DeleteRequest deleteRequest;

    private WriteRequest(BuilderImpl builder) {
        this.putRequest = builder.putRequest;
        this.deleteRequest = builder.deleteRequest;
    }

    /**
     * <p>
     * A request to perform a <code>PutItem</code> operation.
     * </p>
     * 
     * @return A request to perform a <code>PutItem</code> operation.
     */
    public final PutRequest putRequest() {
        return putRequest;
    }

    /**
     * <p>
     * A request to perform a <code>DeleteItem</code> operation.
     * </p>
     * 
     * @return A request to perform a <code>DeleteItem</code> operation.
     */
    public final DeleteRequest deleteRequest() {
        return deleteRequest;
    }

    @Override
    public Builder toBuilder() {
        return new BuilderImpl(this);
    }

    public static Builder builder() {
        return new BuilderImpl();
    }

    public static Class<? extends Builder> serializableBuilderClass() {
        return BuilderImpl.class;
    }

    @Override
    public final int hashCode() {
        int hashCode = 1;
        hashCode = 31 * hashCode + Objects.hashCode(putRequest());
        hashCode = 31 * hashCode + Objects.hashCode(deleteRequest());
        return hashCode;
    }

    @Override
    public final boolean equals(Object obj) {
        return equalsBySdkFields(obj);
    }

    @Override
    public final boolean equalsBySdkFields(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (!(obj instanceof WriteRequest)) {
            return false;
        }
        WriteRequest other = (WriteRequest) obj;
        return Objects.equals(putRequest(), other.putRequest()) && Objects.equals(deleteRequest(), other.deleteRequest());
    }

    /**
     * Returns a string representation of this object. This is useful for testing and debugging. Sensitive data will be
     * redacted from this string using a placeholder value.
     */
    @Override
    public final String toString() {
        return ToString.builder("WriteRequest").add("PutRequest", putRequest()).add("DeleteRequest", deleteRequest()).build();
    }

    public final <T> Optional<T> getValueForField(String fieldName, Class<T> clazz) {
        switch (fieldName) {
        case "PutRequest":
            return Optional.ofNullable(clazz.cast(putRequest()));
        case "DeleteRequest":
            return Optional.ofNullable(clazz.cast(deleteRequest()));
        default:
            return Optional.empty();
        }
    }

    @Override
    public final List<SdkField<?>> sdkFields() {
        return SDK_FIELDS;
    }

    private static <T> Function<Object, T> getter(Function<WriteRequest, T> g) {
        return obj -> g.apply((WriteRequest) obj);
    }

    private static <T> BiConsumer<Object, T> setter(BiConsumer<Builder, T> s) {
        return (obj, val) -> s.accept((Builder) obj, val);
    }

    public interface Builder extends SdkPojo, CopyableBuilder<Builder, WriteRequest> {
        /**
         * <p>
         * A request to perform a <code>PutItem</code> operation.
         * </p>
         * 
         * @param putRequest
         *        A request to perform a <code>PutItem</code> operation.
         * @return Returns a reference to this object so that method calls can be chained together.
         */
        Builder putRequest(PutRequest putRequest);

        /**
         * <p>
         * A request to perform a <code>PutItem</code> operation.
         * </p>
         * This is a convenience method that creates an instance of the {@link PutRequest.Builder} avoiding the need to
         * create one manually via {@link PutRequest#builder()}.
         *
         * <p>
         * When the {@link Consumer} completes, {@link PutRequest.Builder#build()} is called immediately and its result
         * is passed to {@link #putRequest(PutRequest)}.
         * 
         * @param putRequest
         *        a consumer that will call methods on {@link PutRequest.Builder}
         * @return Returns a reference to this object so that method calls can be chained together.
         * @see #putRequest(PutRequest)
         */
        default Builder putRequest(Consumer<PutRequest.Builder> putRequest) {
            return putRequest(PutRequest.builder().applyMutation(putRequest).build());
        }

        /**
         * <p>
         * A request to perform a <code>DeleteItem</code> operation.
         * </p>
         * 
         * @param deleteRequest
         *        A request to perform a <code>DeleteItem</code> operation.
         * @return Returns a reference to this object so that method calls can be chained together.
         */
        Builder deleteRequest(DeleteRequest deleteRequest);

        /**
         * <p>
         * A request to perform a <code>DeleteItem</code> operation.
         * </p>
         * This is a convenience method that creates an instance of the {@link DeleteRequest.Builder} avoiding the need
         * to create one manually via {@link DeleteRequest#builder()}.
         *
         * <p>
         * When the {@link Consumer} completes, {@link DeleteRequest.Builder#build()} is called immediately and its
         * result is passed to {@link #deleteRequest(DeleteRequest)}.
         * 
         * @param deleteRequest
         *        a consumer that will call methods on {@link DeleteRequest.Builder}
         * @return Returns a reference to this object so that method calls can be chained together.
         * @see #deleteRequest(DeleteRequest)
         */
        default Builder deleteRequest(Consumer<DeleteRequest.Builder> deleteRequest) {
            return deleteRequest(DeleteRequest.builder().applyMutation(deleteRequest).build());
        }
    }

    static final class BuilderImpl implements Builder {
        private PutRequest putRequest;

        private DeleteRequest deleteRequest;

        private BuilderImpl() {
        }

        private BuilderImpl(WriteRequest model) {
            putRequest(model.putRequest);
            deleteRequest(model.deleteRequest);
        }

        public final PutRequest.Builder getPutRequest() {
            return putRequest != null ? putRequest.toBuilder() : null;
        }

        public final void setPutRequest(PutRequest.BuilderImpl putRequest) {
            this.putRequest = putRequest != null ? putRequest.build() : null;
        }

        @Override
        public final Builder putRequest(PutRequest putRequest) {
            this.putRequest = putRequest;
            return this;
        }

        public final DeleteRequest.Builder getDeleteRequest() {
            return deleteRequest != null ? deleteRequest.toBuilder() : null;
        }

        public final void setDeleteRequest(DeleteRequest.BuilderImpl deleteRequest) {
            this.deleteRequest = deleteRequest != null ? deleteRequest.build() : null;
        }

        @Override
        public final Builder deleteRequest(DeleteRequest deleteRequest) {
            this.deleteRequest = deleteRequest;
            return this;
        }

        @Override
        public WriteRequest build() {
            return new WriteRequest(this);
        }

        @Override
        public List<SdkField<?>> sdkFields() {
            return SDK_FIELDS;
        }
    }
}
