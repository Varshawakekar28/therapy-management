/*
 * Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
 * 
 * Licensed under the Apache License, Version 2.0 (the "License"). You may not use this file except in compliance with
 * the License. A copy of the License is located at
 * 
 * http://aws.amazon.com/apache2.0
 * 
 * or in the "license" file accompanying this file. This file is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR
 * CONDITIONS OF ANY KIND, either express or implied. See the License for the specific language governing permissions
 * and limitations under the License.
 */

package software.amazon.awssdk.services.dynamodb.model;

import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.function.BiConsumer;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.stream.Collectors;
import java.util.stream.Stream;
import software.amazon.awssdk.annotations.Generated;
import software.amazon.awssdk.awscore.exception.AwsErrorDetails;
import software.amazon.awssdk.core.SdkField;
import software.amazon.awssdk.core.SdkPojo;
import software.amazon.awssdk.core.protocol.MarshallLocation;
import software.amazon.awssdk.core.protocol.MarshallingType;
import software.amazon.awssdk.core.traits.ListTrait;
import software.amazon.awssdk.core.traits.LocationTrait;
import software.amazon.awssdk.core.util.DefaultSdkAutoConstructList;
import software.amazon.awssdk.core.util.SdkAutoConstructList;
import software.amazon.awssdk.utils.builder.CopyableBuilder;
import software.amazon.awssdk.utils.builder.ToCopyableBuilder;

/**
 * <p>
 * The entire transaction request was canceled.
 * </p>
 * <p>
 * DynamoDB cancels a <code>TransactWriteItems</code> request under the following circumstances:
 * </p>
 * <ul>
 * <li>
 * <p>
 * A condition in one of the condition expressions is not met.
 * </p>
 * </li>
 * <li>
 * <p>
 * A table in the <code>TransactWriteItems</code> request is in a different account or region.
 * </p>
 * </li>
 * <li>
 * <p>
 * More than one action in the <code>TransactWriteItems</code> operation targets the same item.
 * </p>
 * </li>
 * <li>
 * <p>
 * There is insufficient provisioned capacity for the transaction to be completed.
 * </p>
 * </li>
 * <li>
 * <p>
 * An item size becomes too large (larger than 400 KB), or a local secondary index (LSI) becomes too large, or a similar
 * validation error occurs because of changes made by the transaction.
 * </p>
 * </li>
 * <li>
 * <p>
 * There is a user error, such as an invalid data format.
 * </p>
 * </li>
 * </ul>
 * <p>
 * DynamoDB cancels a <code>TransactGetItems</code> request under the following circumstances:
 * </p>
 * <ul>
 * <li>
 * <p>
 * There is an ongoing <code>TransactGetItems</code> operation that conflicts with a concurrent <code>PutItem</code>,
 * <code>UpdateItem</code>, <code>DeleteItem</code> or <code>TransactWriteItems</code> request. In this case the
 * <code>TransactGetItems</code> operation fails with a <code>TransactionCanceledException</code>.
 * </p>
 * </li>
 * <li>
 * <p>
 * A table in the <code>TransactGetItems</code> request is in a different account or region.
 * </p>
 * </li>
 * <li>
 * <p>
 * There is insufficient provisioned capacity for the transaction to be completed.
 * </p>
 * </li>
 * <li>
 * <p>
 * There is a user error, such as an invalid data format.
 * </p>
 * </li>
 * </ul>
 * <note>
 * <p>
 * If using Java, DynamoDB lists the cancellation reasons on the <code>CancellationReasons</code> property. This
 * property is not set for other languages. Transaction cancellation reasons are ordered in the order of requested
 * items, if an item has no error it will have <code>None</code> code and <code>Null</code> message.
 * </p>
 * </note>
 * <p>
 * Cancellation reason codes and possible error messages:
 * </p>
 * <ul>
 * <li>
 * <p>
 * No Errors:
 * </p>
 * <ul>
 * <li>
 * <p>
 * Code: <code>None</code>
 * </p>
 * </li>
 * <li>
 * <p>
 * Message: <code>null</code>
 * </p>
 * </li>
 * </ul>
 * </li>
 * <li>
 * <p>
 * Conditional Check Failed:
 * </p>
 * <ul>
 * <li>
 * <p>
 * Code: <code>ConditionalCheckFailed</code>
 * </p>
 * </li>
 * <li>
 * <p>
 * Message: The conditional request failed.
 * </p>
 * </li>
 * </ul>
 * </li>
 * <li>
 * <p>
 * Item Collection Size Limit Exceeded:
 * </p>
 * <ul>
 * <li>
 * <p>
 * Code: <code>ItemCollectionSizeLimitExceeded</code>
 * </p>
 * </li>
 * <li>
 * <p>
 * Message: Collection size exceeded.
 * </p>
 * </li>
 * </ul>
 * </li>
 * <li>
 * <p>
 * Transaction Conflict:
 * </p>
 * <ul>
 * <li>
 * <p>
 * Code: <code>TransactionConflict</code>
 * </p>
 * </li>
 * <li>
 * <p>
 * Message: Transaction is ongoing for the item.
 * </p>
 * </li>
 * </ul>
 * </li>
 * <li>
 * <p>
 * Provisioned Throughput Exceeded:
 * </p>
 * <ul>
 * <li>
 * <p>
 * Code: <code>ProvisionedThroughputExceeded</code>
 * </p>
 * </li>
 * <li>
 * <p>
 * Messages:
 * </p>
 * <ul>
 * <li>
 * <p>
 * The level of configured provisioned throughput for the table was exceeded. Consider increasing your provisioning
 * level with the UpdateTable API.
 * </p>
 * <note>
 * <p>
 * This Message is received when provisioned throughput is exceeded is on a provisioned DynamoDB table.
 * </p>
 * </note></li>
 * <li>
 * <p>
 * The level of configured provisioned throughput for one or more global secondary indexes of the table was exceeded.
 * Consider increasing your provisioning level for the under-provisioned global secondary indexes with the UpdateTable
 * API.
 * </p>
 * <note>
 * <p>
 * This message is returned when provisioned throughput is exceeded is on a provisioned GSI.
 * </p>
 * </note></li>
 * </ul>
 * </li>
 * </ul>
 * </li>
 * <li>
 * <p>
 * Throttling Error:
 * </p>
 * <ul>
 * <li>
 * <p>
 * Code: <code>ThrottlingError</code>
 * </p>
 * </li>
 * <li>
 * <p>
 * Messages:
 * </p>
 * <ul>
 * <li>
 * <p>
 * Throughput exceeds the current capacity of your table or index. DynamoDB is automatically scaling your table or index
 * so please try again shortly. If exceptions persist, check if you have a hot key:
 * https://docs.aws.amazon.com/amazondynamodb/latest/developerguide/bp-partition-key-design.html.
 * </p>
 * <note>
 * <p>
 * This message is returned when writes get throttled on an On-Demand table as DynamoDB is automatically scaling the
 * table.
 * </p>
 * </note></li>
 * <li>
 * <p>
 * Throughput exceeds the current capacity for one or more global secondary indexes. DynamoDB is automatically scaling
 * your index so please try again shortly.
 * </p>
 * <note>
 * <p>
 * This message is returned when writes get throttled on an On-Demand GSI as DynamoDB is automatically scaling the GSI.
 * </p>
 * </note></li>
 * </ul>
 * </li>
 * </ul>
 * </li>
 * <li>
 * <p>
 * Validation Error:
 * </p>
 * <ul>
 * <li>
 * <p>
 * Code: <code>ValidationError</code>
 * </p>
 * </li>
 * <li>
 * <p>
 * Messages:
 * </p>
 * <ul>
 * <li>
 * <p>
 * One or more parameter values were invalid.
 * </p>
 * </li>
 * <li>
 * <p>
 * The update expression attempted to update the secondary index key beyond allowed size limits.
 * </p>
 * </li>
 * <li>
 * <p>
 * The update expression attempted to update the secondary index key to unsupported type.
 * </p>
 * </li>
 * <li>
 * <p>
 * An operand in the update expression has an incorrect data type.
 * </p>
 * </li>
 * <li>
 * <p>
 * Item size to update has exceeded the maximum allowed size.
 * </p>
 * </li>
 * <li>
 * <p>
 * Number overflow. Attempting to store a number with magnitude larger than supported range.
 * </p>
 * </li>
 * <li>
 * <p>
 * Type mismatch for attribute to update.
 * </p>
 * </li>
 * <li>
 * <p>
 * Nesting Levels have exceeded supported limits.
 * </p>
 * </li>
 * <li>
 * <p>
 * The document path provided in the update expression is invalid for update.
 * </p>
 * </li>
 * <li>
 * <p>
 * The provided expression refers to an attribute that does not exist in the item.
 * </p>
 * </li>
 * </ul>
 * </li>
 * </ul>
 * </li>
 * </ul>
 */
@Generated("software.amazon.awssdk:codegen")
public final class TransactionCanceledException extends DynamoDbException implements
        ToCopyableBuilder<TransactionCanceledException.Builder, TransactionCanceledException> {
    private static final SdkField<List<CancellationReason>> CANCELLATION_REASONS_FIELD = SdkField
            .<List<CancellationReason>> builder(MarshallingType.LIST)
            .memberName("CancellationReasons")
            .getter(getter(TransactionCanceledException::cancellationReasons))
            .setter(setter(Builder::cancellationReasons))
            .traits(LocationTrait.builder().location(MarshallLocation.PAYLOAD).locationName("CancellationReasons").build(),
                    ListTrait
                            .builder()
                            .memberLocationName(null)
                            .memberFieldInfo(
                                    SdkField.<CancellationReason> builder(MarshallingType.SDK_POJO)
                                            .constructor(CancellationReason::builder)
                                            .traits(LocationTrait.builder().location(MarshallLocation.PAYLOAD)
                                                    .locationName("member").build()).build()).build()).build();

    private static final List<SdkField<?>> SDK_FIELDS = Collections.unmodifiableList(Arrays.asList(CANCELLATION_REASONS_FIELD));

    private static final long serialVersionUID = 1L;

    private final List<CancellationReason> cancellationReasons;

    private TransactionCanceledException(BuilderImpl builder) {
        super(builder);
        this.cancellationReasons = builder.cancellationReasons;
    }

    @Override
    public Builder toBuilder() {
        return new BuilderImpl(this);
    }

    public static Builder builder() {
        return new BuilderImpl();
    }

    public static Class<? extends Builder> serializableBuilderClass() {
        return BuilderImpl.class;
    }

    /**
     * For responses, this returns true if the service returned a value for the CancellationReasons property. This DOES
     * NOT check that the value is non-empty (for which, you should check the {@code isEmpty()} method on the property).
     * This is useful because the SDK will never return a null collection or map, but you may need to differentiate
     * between the service returning nothing (or null) and the service returning an empty collection or map. For
     * requests, this returns true if a value for the property was specified in the request builder, and false if a
     * value was not specified.
     */
    public boolean hasCancellationReasons() {
        return cancellationReasons != null && !(cancellationReasons instanceof SdkAutoConstructList);
    }

    /**
     * <p>
     * A list of cancellation reasons.
     * </p>
     * <p>
     * Attempts to modify the collection returned by this method will result in an UnsupportedOperationException.
     * </p>
     * <p>
     * This method will never return null. If you would like to know whether the service returned this field (so that
     * you can differentiate between null and empty), you can use the {@link #hasCancellationReasons} method.
     * </p>
     * 
     * @return A list of cancellation reasons.
     */
    public List<CancellationReason> cancellationReasons() {
        return cancellationReasons;
    }

    @Override
    public final List<SdkField<?>> sdkFields() {
        return SDK_FIELDS;
    }

    private static <T> Function<Object, T> getter(Function<TransactionCanceledException, T> g) {
        return obj -> g.apply((TransactionCanceledException) obj);
    }

    private static <T> BiConsumer<Object, T> setter(BiConsumer<Builder, T> s) {
        return (obj, val) -> s.accept((Builder) obj, val);
    }

    public interface Builder extends SdkPojo, CopyableBuilder<Builder, TransactionCanceledException>, DynamoDbException.Builder {
        /**
         * <p>
         * A list of cancellation reasons.
         * </p>
         * 
         * @param cancellationReasons
         *        A list of cancellation reasons.
         * @return Returns a reference to this object so that method calls can be chained together.
         */
        Builder cancellationReasons(Collection<CancellationReason> cancellationReasons);

        /**
         * <p>
         * A list of cancellation reasons.
         * </p>
         * 
         * @param cancellationReasons
         *        A list of cancellation reasons.
         * @return Returns a reference to this object so that method calls can be chained together.
         */
        Builder cancellationReasons(CancellationReason... cancellationReasons);

        /**
         * <p>
         * A list of cancellation reasons.
         * </p>
         * This is a convenience method that creates an instance of the
         * {@link software.amazon.awssdk.services.dynamodb.model.CancellationReason.Builder} avoiding the need to create
         * one manually via {@link software.amazon.awssdk.services.dynamodb.model.CancellationReason#builder()}.
         *
         * <p>
         * When the {@link Consumer} completes,
         * {@link software.amazon.awssdk.services.dynamodb.model.CancellationReason.Builder#build()} is called
         * immediately and its result is passed to {@link #cancellationReasons(List<CancellationReason>)}.
         * 
         * @param cancellationReasons
         *        a consumer that will call methods on
         *        {@link software.amazon.awssdk.services.dynamodb.model.CancellationReason.Builder}
         * @return Returns a reference to this object so that method calls can be chained together.
         * @see #cancellationReasons(java.util.Collection<CancellationReason>)
         */
        Builder cancellationReasons(Consumer<CancellationReason.Builder>... cancellationReasons);

        @Override
        Builder awsErrorDetails(AwsErrorDetails awsErrorDetails);

        @Override
        Builder message(String message);

        @Override
        Builder requestId(String requestId);

        @Override
        Builder statusCode(int statusCode);

        @Override
        Builder cause(Throwable cause);

        @Override
        Builder writableStackTrace(Boolean writableStackTrace);
    }

    static final class BuilderImpl extends DynamoDbException.BuilderImpl implements Builder {
        private List<CancellationReason> cancellationReasons = DefaultSdkAutoConstructList.getInstance();

        private BuilderImpl() {
        }

        private BuilderImpl(TransactionCanceledException model) {
            super(model);
            cancellationReasons(model.cancellationReasons);
        }

        public final List<CancellationReason.Builder> getCancellationReasons() {
            List<CancellationReason.Builder> result = CancellationReasonListCopier.copyToBuilder(this.cancellationReasons);
            if (result instanceof SdkAutoConstructList) {
                return null;
            }
            return result;
        }

        public final void setCancellationReasons(Collection<CancellationReason.BuilderImpl> cancellationReasons) {
            this.cancellationReasons = CancellationReasonListCopier.copyFromBuilder(cancellationReasons);
        }

        @Override
        public final Builder cancellationReasons(Collection<CancellationReason> cancellationReasons) {
            this.cancellationReasons = CancellationReasonListCopier.copy(cancellationReasons);
            return this;
        }

        @Override
        @SafeVarargs
        public final Builder cancellationReasons(CancellationReason... cancellationReasons) {
            cancellationReasons(Arrays.asList(cancellationReasons));
            return this;
        }

        @Override
        @SafeVarargs
        public final Builder cancellationReasons(Consumer<CancellationReason.Builder>... cancellationReasons) {
            cancellationReasons(Stream.of(cancellationReasons).map(c -> CancellationReason.builder().applyMutation(c).build())
                    .collect(Collectors.toList()));
            return this;
        }

        @Override
        public BuilderImpl awsErrorDetails(AwsErrorDetails awsErrorDetails) {
            this.awsErrorDetails = awsErrorDetails;
            return this;
        }

        @Override
        public BuilderImpl message(String message) {
            this.message = message;
            return this;
        }

        @Override
        public BuilderImpl requestId(String requestId) {
            this.requestId = requestId;
            return this;
        }

        @Override
        public BuilderImpl statusCode(int statusCode) {
            this.statusCode = statusCode;
            return this;
        }

        @Override
        public BuilderImpl cause(Throwable cause) {
            this.cause = cause;
            return this;
        }

        @Override
        public BuilderImpl writableStackTrace(Boolean writableStackTrace) {
            this.writableStackTrace = writableStackTrace;
            return this;
        }

        @Override
        public TransactionCanceledException build() {
            return new TransactionCanceledException(this);
        }

        @Override
        public List<SdkField<?>> sdkFields() {
            return SDK_FIELDS;
        }
    }
}
