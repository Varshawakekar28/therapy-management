/*
 * Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
 * 
 * Licensed under the Apache License, Version 2.0 (the "License"). You may not use this file except in compliance with
 * the License. A copy of the License is located at
 * 
 * http://aws.amazon.com/apache2.0
 * 
 * or in the "license" file accompanying this file. This file is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR
 * CONDITIONS OF ANY KIND, either express or implied. See the License for the specific language governing permissions
 * and limitations under the License.
 */

package software.amazon.awssdk.services.lambda.model;

import java.util.EnumSet;
import java.util.Map;
import java.util.Set;
import software.amazon.awssdk.annotations.Generated;
import software.amazon.awssdk.utils.internal.EnumUtils;

@Generated("software.amazon.awssdk:codegen")
public enum Runtime {
    NODEJS("nodejs"),

    NODEJS4_3("nodejs4.3"),

    NODEJS6_10("nodejs6.10"),

    NODEJS8_10("nodejs8.10"),

    NODEJS10_X("nodejs10.x"),

    NODEJS12_X("nodejs12.x"),

    NODEJS14_X("nodejs14.x"),

    NODEJS16_X("nodejs16.x"),

    JAVA8("java8"),

    JAVA8_AL2("java8.al2"),

    JAVA11("java11"),

    PYTHON2_7("python2.7"),

    PYTHON3_6("python3.6"),

    PYTHON3_7("python3.7"),

    PYTHON3_8("python3.8"),

    PYTHON3_9("python3.9"),

    DOTNETCORE1_0("dotnetcore1.0"),

    DOTNETCORE2_0("dotnetcore2.0"),

    DOTNETCORE2_1("dotnetcore2.1"),

    DOTNETCORE3_1("dotnetcore3.1"),

    DOTNET6("dotnet6"),

    NODEJS4_3_EDGE("nodejs4.3-edge"),

    GO1_X("go1.x"),

    RUBY2_5("ruby2.5"),

    RUBY2_7("ruby2.7"),

    PROVIDED("provided"),

    PROVIDED_AL2("provided.al2"),

    NODEJS18_X("nodejs18.x"),

    UNKNOWN_TO_SDK_VERSION(null);

    private static final Map<String, Runtime> VALUE_MAP = EnumUtils.uniqueIndex(Runtime.class, Runtime::toString);

    private final String value;

    private Runtime(String value) {
        this.value = value;
    }

    @Override
    public String toString() {
        return String.valueOf(value);
    }

    /**
     * Use this in place of valueOf to convert the raw string returned by the service into the enum value.
     *
     * @param value
     *        real value
     * @return Runtime corresponding to the value
     */
    public static Runtime fromValue(String value) {
        if (value == null) {
            return null;
        }
        return VALUE_MAP.getOrDefault(value, UNKNOWN_TO_SDK_VERSION);
    }

    /**
     * Use this in place of {@link #values()} to return a {@link Set} of all values known to the SDK. This will return
     * all known enum values except {@link #UNKNOWN_TO_SDK_VERSION}.
     *
     * @return a {@link Set} of known {@link Runtime}s
     */
    public static Set<Runtime> knownValues() {
        Set<Runtime> knownValues = EnumSet.allOf(Runtime.class);
        knownValues.remove(UNKNOWN_TO_SDK_VERSION);
        return knownValues;
    }
}
