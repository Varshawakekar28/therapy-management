/*
 * Copyright 2018-2023 Amazon.com, Inc. or its affiliates. All Rights Reserved.
 * 
 * Licensed under the Apache License, Version 2.0 (the "License"). You may not use this file except in compliance with
 * the License. A copy of the License is located at
 * 
 * http://aws.amazon.com/apache2.0
 * 
 * or in the "license" file accompanying this file. This file is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR
 * CONDITIONS OF ANY KIND, either express or implied. See the License for the specific language governing permissions
 * and limitations under the License.
 */

package software.amazon.awssdk.regions.servicemetadata;

import java.net.URI;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import software.amazon.awssdk.annotations.Generated;
import software.amazon.awssdk.annotations.SdkPublicApi;
import software.amazon.awssdk.regions.EndpointTag;
import software.amazon.awssdk.regions.PartitionEndpointKey;
import software.amazon.awssdk.regions.Region;
import software.amazon.awssdk.regions.ServiceEndpointKey;
import software.amazon.awssdk.regions.ServiceMetadata;
import software.amazon.awssdk.regions.ServicePartitionMetadata;
import software.amazon.awssdk.regions.internal.DefaultServicePartitionMetadata;
import software.amazon.awssdk.regions.internal.util.ServiceMetadataUtils;
import software.amazon.awssdk.utils.ImmutableMap;
import software.amazon.awssdk.utils.Pair;

@Generated("software.amazon.awssdk:codegen")
@SdkPublicApi
public final class WafRegionalServiceMetadata implements ServiceMetadata {
    private static final String ENDPOINT_PREFIX = "waf-regional";

    private static final List<Region> REGIONS = Collections.unmodifiableList(Arrays.asList(Region.of("af-south-1"),
            Region.of("ap-east-1"), Region.of("ap-northeast-1"), Region.of("ap-northeast-2"), Region.of("ap-northeast-3"),
            Region.of("ap-south-1"), Region.of("ap-south-2"), Region.of("ap-southeast-1"), Region.of("ap-southeast-2"),
            Region.of("ap-southeast-3"), Region.of("ap-southeast-4"), Region.of("ca-central-1"), Region.of("eu-central-1"),
            Region.of("eu-central-2"), Region.of("eu-north-1"), Region.of("eu-south-1"), Region.of("eu-south-2"),
            Region.of("eu-west-1"), Region.of("eu-west-2"), Region.of("eu-west-3"), Region.of("fips-af-south-1"),
            Region.of("fips-ap-east-1"), Region.of("fips-ap-northeast-1"), Region.of("fips-ap-northeast-2"),
            Region.of("fips-ap-northeast-3"), Region.of("fips-ap-south-1"), Region.of("fips-ap-southeast-1"),
            Region.of("fips-ap-southeast-2"), Region.of("fips-ca-central-1"), Region.of("fips-eu-central-1"),
            Region.of("fips-eu-north-1"), Region.of("fips-eu-south-1"), Region.of("fips-eu-west-1"), Region.of("fips-eu-west-2"),
            Region.of("fips-eu-west-3"), Region.of("fips-me-south-1"), Region.of("fips-sa-east-1"), Region.of("fips-us-east-1"),
            Region.of("fips-us-east-2"), Region.of("fips-us-west-1"), Region.of("fips-us-west-2"), Region.of("me-central-1"),
            Region.of("me-south-1"), Region.of("sa-east-1"), Region.of("us-east-1"), Region.of("us-east-2"),
            Region.of("us-west-1"), Region.of("us-west-2"), Region.of("cn-north-1"), Region.of("cn-northwest-1"),
            Region.of("fips-cn-north-1"), Region.of("fips-cn-northwest-1"), Region.of("fips-us-gov-east-1"),
            Region.of("fips-us-gov-west-1"), Region.of("us-gov-east-1"), Region.of("us-gov-west-1")));

    private static final List<ServicePartitionMetadata> PARTITIONS = Collections.unmodifiableList(Arrays.asList(
            new DefaultServicePartitionMetadata("aws", null), new DefaultServicePartitionMetadata("aws-cn", null),
            new DefaultServicePartitionMetadata("aws-us-gov", null)));

    private static final Map<ServiceEndpointKey, String> SIGNING_REGIONS_BY_REGION = ImmutableMap
            .<ServiceEndpointKey, String> builder()
            .put(ServiceEndpointKey.builder().region(Region.of("af-south-1")).build(), "af-south-1")
            .put(ServiceEndpointKey.builder().region(Region.of("af-south-1")).tags(EndpointTag.of("fips")).build(), "af-south-1")
            .put(ServiceEndpointKey.builder().region(Region.of("ap-east-1")).build(), "ap-east-1")
            .put(ServiceEndpointKey.builder().region(Region.of("ap-east-1")).tags(EndpointTag.of("fips")).build(), "ap-east-1")
            .put(ServiceEndpointKey.builder().region(Region.of("ap-northeast-1")).build(), "ap-northeast-1")
            .put(ServiceEndpointKey.builder().region(Region.of("ap-northeast-1")).tags(EndpointTag.of("fips")).build(),
                    "ap-northeast-1")
            .put(ServiceEndpointKey.builder().region(Region.of("ap-northeast-2")).build(), "ap-northeast-2")
            .put(ServiceEndpointKey.builder().region(Region.of("ap-northeast-2")).tags(EndpointTag.of("fips")).build(),
                    "ap-northeast-2")
            .put(ServiceEndpointKey.builder().region(Region.of("ap-northeast-3")).build(), "ap-northeast-3")
            .put(ServiceEndpointKey.builder().region(Region.of("ap-northeast-3")).tags(EndpointTag.of("fips")).build(),
                    "ap-northeast-3")
            .put(ServiceEndpointKey.builder().region(Region.of("ap-south-1")).build(), "ap-south-1")
            .put(ServiceEndpointKey.builder().region(Region.of("ap-south-1")).tags(EndpointTag.of("fips")).build(), "ap-south-1")
            .put(ServiceEndpointKey.builder().region(Region.of("ap-south-2")).build(), "ap-south-2")
            .put(ServiceEndpointKey.builder().region(Region.of("ap-south-2")).tags(EndpointTag.of("fips")).build(), "ap-south-2")
            .put(ServiceEndpointKey.builder().region(Region.of("ap-southeast-1")).build(), "ap-southeast-1")
            .put(ServiceEndpointKey.builder().region(Region.of("ap-southeast-1")).tags(EndpointTag.of("fips")).build(),
                    "ap-southeast-1")
            .put(ServiceEndpointKey.builder().region(Region.of("ap-southeast-2")).build(), "ap-southeast-2")
            .put(ServiceEndpointKey.builder().region(Region.of("ap-southeast-2")).tags(EndpointTag.of("fips")).build(),
                    "ap-southeast-2")
            .put(ServiceEndpointKey.builder().region(Region.of("ap-southeast-3")).build(), "ap-southeast-3")
            .put(ServiceEndpointKey.builder().region(Region.of("ap-southeast-3")).tags(EndpointTag.of("fips")).build(),
                    "ap-southeast-3")
            .put(ServiceEndpointKey.builder().region(Region.of("ap-southeast-4")).build(), "ap-southeast-4")
            .put(ServiceEndpointKey.builder().region(Region.of("ap-southeast-4")).tags(EndpointTag.of("fips")).build(),
                    "ap-southeast-4")
            .put(ServiceEndpointKey.builder().region(Region.of("ca-central-1")).build(), "ca-central-1")
            .put(ServiceEndpointKey.builder().region(Region.of("ca-central-1")).tags(EndpointTag.of("fips")).build(),
                    "ca-central-1")
            .put(ServiceEndpointKey.builder().region(Region.of("eu-central-1")).build(), "eu-central-1")
            .put(ServiceEndpointKey.builder().region(Region.of("eu-central-1")).tags(EndpointTag.of("fips")).build(),
                    "eu-central-1")
            .put(ServiceEndpointKey.builder().region(Region.of("eu-central-2")).build(), "eu-central-2")
            .put(ServiceEndpointKey.builder().region(Region.of("eu-central-2")).tags(EndpointTag.of("fips")).build(),
                    "eu-central-2")
            .put(ServiceEndpointKey.builder().region(Region.of("eu-north-1")).build(), "eu-north-1")
            .put(ServiceEndpointKey.builder().region(Region.of("eu-north-1")).tags(EndpointTag.of("fips")).build(), "eu-north-1")
            .put(ServiceEndpointKey.builder().region(Region.of("eu-south-1")).build(), "eu-south-1")
            .put(ServiceEndpointKey.builder().region(Region.of("eu-south-1")).tags(EndpointTag.of("fips")).build(), "eu-south-1")
            .put(ServiceEndpointKey.builder().region(Region.of("eu-south-2")).build(), "eu-south-2")
            .put(ServiceEndpointKey.builder().region(Region.of("eu-south-2")).tags(EndpointTag.of("fips")).build(), "eu-south-2")
            .put(ServiceEndpointKey.builder().region(Region.of("eu-west-1")).build(), "eu-west-1")
            .put(ServiceEndpointKey.builder().region(Region.of("eu-west-1")).tags(EndpointTag.of("fips")).build(), "eu-west-1")
            .put(ServiceEndpointKey.builder().region(Region.of("eu-west-2")).build(), "eu-west-2")
            .put(ServiceEndpointKey.builder().region(Region.of("eu-west-2")).tags(EndpointTag.of("fips")).build(), "eu-west-2")
            .put(ServiceEndpointKey.builder().region(Region.of("eu-west-3")).build(), "eu-west-3")
            .put(ServiceEndpointKey.builder().region(Region.of("eu-west-3")).tags(EndpointTag.of("fips")).build(), "eu-west-3")
            .put(ServiceEndpointKey.builder().region(Region.of("fips-af-south-1")).build(), "af-south-1")
            .put(ServiceEndpointKey.builder().region(Region.of("fips-ap-east-1")).build(), "ap-east-1")
            .put(ServiceEndpointKey.builder().region(Region.of("fips-ap-northeast-1")).build(), "ap-northeast-1")
            .put(ServiceEndpointKey.builder().region(Region.of("fips-ap-northeast-2")).build(), "ap-northeast-2")
            .put(ServiceEndpointKey.builder().region(Region.of("fips-ap-northeast-3")).build(), "ap-northeast-3")
            .put(ServiceEndpointKey.builder().region(Region.of("fips-ap-south-1")).build(), "ap-south-1")
            .put(ServiceEndpointKey.builder().region(Region.of("fips-ap-southeast-1")).build(), "ap-southeast-1")
            .put(ServiceEndpointKey.builder().region(Region.of("fips-ap-southeast-2")).build(), "ap-southeast-2")
            .put(ServiceEndpointKey.builder().region(Region.of("fips-ca-central-1")).build(), "ca-central-1")
            .put(ServiceEndpointKey.builder().region(Region.of("fips-eu-central-1")).build(), "eu-central-1")
            .put(ServiceEndpointKey.builder().region(Region.of("fips-eu-north-1")).build(), "eu-north-1")
            .put(ServiceEndpointKey.builder().region(Region.of("fips-eu-south-1")).build(), "eu-south-1")
            .put(ServiceEndpointKey.builder().region(Region.of("fips-eu-west-1")).build(), "eu-west-1")
            .put(ServiceEndpointKey.builder().region(Region.of("fips-eu-west-2")).build(), "eu-west-2")
            .put(ServiceEndpointKey.builder().region(Region.of("fips-eu-west-3")).build(), "eu-west-3")
            .put(ServiceEndpointKey.builder().region(Region.of("fips-me-south-1")).build(), "me-south-1")
            .put(ServiceEndpointKey.builder().region(Region.of("fips-sa-east-1")).build(), "sa-east-1")
            .put(ServiceEndpointKey.builder().region(Region.of("fips-us-east-1")).build(), "us-east-1")
            .put(ServiceEndpointKey.builder().region(Region.of("fips-us-east-2")).build(), "us-east-2")
            .put(ServiceEndpointKey.builder().region(Region.of("fips-us-west-1")).build(), "us-west-1")
            .put(ServiceEndpointKey.builder().region(Region.of("fips-us-west-2")).build(), "us-west-2")
            .put(ServiceEndpointKey.builder().region(Region.of("me-central-1")).build(), "me-central-1")
            .put(ServiceEndpointKey.builder().region(Region.of("me-central-1")).tags(EndpointTag.of("fips")).build(),
                    "me-central-1")
            .put(ServiceEndpointKey.builder().region(Region.of("me-south-1")).build(), "me-south-1")
            .put(ServiceEndpointKey.builder().region(Region.of("me-south-1")).tags(EndpointTag.of("fips")).build(), "me-south-1")
            .put(ServiceEndpointKey.builder().region(Region.of("sa-east-1")).build(), "sa-east-1")
            .put(ServiceEndpointKey.builder().region(Region.of("sa-east-1")).tags(EndpointTag.of("fips")).build(), "sa-east-1")
            .put(ServiceEndpointKey.builder().region(Region.of("us-east-1")).build(), "us-east-1")
            .put(ServiceEndpointKey.builder().region(Region.of("us-east-1")).tags(EndpointTag.of("fips")).build(), "us-east-1")
            .put(ServiceEndpointKey.builder().region(Region.of("us-east-2")).build(), "us-east-2")
            .put(ServiceEndpointKey.builder().region(Region.of("us-east-2")).tags(EndpointTag.of("fips")).build(), "us-east-2")
            .put(ServiceEndpointKey.builder().region(Region.of("us-west-1")).build(), "us-west-1")
            .put(ServiceEndpointKey.builder().region(Region.of("us-west-1")).tags(EndpointTag.of("fips")).build(), "us-west-1")
            .put(ServiceEndpointKey.builder().region(Region.of("us-west-2")).build(), "us-west-2")
            .put(ServiceEndpointKey.builder().region(Region.of("us-west-2")).tags(EndpointTag.of("fips")).build(), "us-west-2")
            .put(ServiceEndpointKey.builder().region(Region.of("cn-north-1")).build(), "cn-north-1")
            .put(ServiceEndpointKey.builder().region(Region.of("cn-north-1")).tags(EndpointTag.of("fips")).build(), "cn-north-1")
            .put(ServiceEndpointKey.builder().region(Region.of("cn-northwest-1")).build(), "cn-northwest-1")
            .put(ServiceEndpointKey.builder().region(Region.of("cn-northwest-1")).tags(EndpointTag.of("fips")).build(),
                    "cn-northwest-1")
            .put(ServiceEndpointKey.builder().region(Region.of("fips-cn-north-1")).build(), "cn-north-1")
            .put(ServiceEndpointKey.builder().region(Region.of("fips-cn-northwest-1")).build(), "cn-northwest-1")
            .put(ServiceEndpointKey.builder().region(Region.of("fips-us-gov-east-1")).build(), "us-gov-east-1")
            .put(ServiceEndpointKey.builder().region(Region.of("fips-us-gov-west-1")).build(), "us-gov-west-1")
            .put(ServiceEndpointKey.builder().region(Region.of("us-gov-east-1")).build(), "us-gov-east-1")
            .put(ServiceEndpointKey.builder().region(Region.of("us-gov-east-1")).tags(EndpointTag.of("fips")).build(),
                    "us-gov-east-1")
            .put(ServiceEndpointKey.builder().region(Region.of("us-gov-west-1")).build(), "us-gov-west-1")
            .put(ServiceEndpointKey.builder().region(Region.of("us-gov-west-1")).tags(EndpointTag.of("fips")).build(),
                    "us-gov-west-1").build();

    private static final Map<Pair<String, PartitionEndpointKey>, String> SIGNING_REGIONS_BY_PARTITION = ImmutableMap
            .<Pair<String, PartitionEndpointKey>, String> builder().build();

    private static final Map<ServiceEndpointKey, String> DNS_SUFFIXES_BY_REGION = ImmutableMap
            .<ServiceEndpointKey, String> builder().build();

    private static final Map<Pair<String, PartitionEndpointKey>, String> DNS_SUFFIXES_BY_PARTITION = ImmutableMap
            .<Pair<String, PartitionEndpointKey>, String> builder().build();

    private static final Map<ServiceEndpointKey, String> HOSTNAMES_BY_REGION = ImmutableMap
            .<ServiceEndpointKey, String> builder()
            .put(ServiceEndpointKey.builder().region(Region.of("af-south-1")).build(), "waf-regional.af-south-1.amazonaws.com")
            .put(ServiceEndpointKey.builder().region(Region.of("af-south-1")).tags(EndpointTag.of("fips")).build(),
                    "waf-regional-fips.af-south-1.amazonaws.com")
            .put(ServiceEndpointKey.builder().region(Region.of("ap-east-1")).build(), "waf-regional.ap-east-1.amazonaws.com")
            .put(ServiceEndpointKey.builder().region(Region.of("ap-east-1")).tags(EndpointTag.of("fips")).build(),
                    "waf-regional-fips.ap-east-1.amazonaws.com")
            .put(ServiceEndpointKey.builder().region(Region.of("ap-northeast-1")).build(),
                    "waf-regional.ap-northeast-1.amazonaws.com")
            .put(ServiceEndpointKey.builder().region(Region.of("ap-northeast-1")).tags(EndpointTag.of("fips")).build(),
                    "waf-regional-fips.ap-northeast-1.amazonaws.com")
            .put(ServiceEndpointKey.builder().region(Region.of("ap-northeast-2")).build(),
                    "waf-regional.ap-northeast-2.amazonaws.com")
            .put(ServiceEndpointKey.builder().region(Region.of("ap-northeast-2")).tags(EndpointTag.of("fips")).build(),
                    "waf-regional-fips.ap-northeast-2.amazonaws.com")
            .put(ServiceEndpointKey.builder().region(Region.of("ap-northeast-3")).build(),
                    "waf-regional.ap-northeast-3.amazonaws.com")
            .put(ServiceEndpointKey.builder().region(Region.of("ap-northeast-3")).tags(EndpointTag.of("fips")).build(),
                    "waf-regional-fips.ap-northeast-3.amazonaws.com")
            .put(ServiceEndpointKey.builder().region(Region.of("ap-south-1")).build(), "waf-regional.ap-south-1.amazonaws.com")
            .put(ServiceEndpointKey.builder().region(Region.of("ap-south-1")).tags(EndpointTag.of("fips")).build(),
                    "waf-regional-fips.ap-south-1.amazonaws.com")
            .put(ServiceEndpointKey.builder().region(Region.of("ap-south-2")).build(), "waf-regional.ap-south-2.amazonaws.com")
            .put(ServiceEndpointKey.builder().region(Region.of("ap-south-2")).tags(EndpointTag.of("fips")).build(),
                    "waf-regional-fips.ap-south-2.amazonaws.com")
            .put(ServiceEndpointKey.builder().region(Region.of("ap-southeast-1")).build(),
                    "waf-regional.ap-southeast-1.amazonaws.com")
            .put(ServiceEndpointKey.builder().region(Region.of("ap-southeast-1")).tags(EndpointTag.of("fips")).build(),
                    "waf-regional-fips.ap-southeast-1.amazonaws.com")
            .put(ServiceEndpointKey.builder().region(Region.of("ap-southeast-2")).build(),
                    "waf-regional.ap-southeast-2.amazonaws.com")
            .put(ServiceEndpointKey.builder().region(Region.of("ap-southeast-2")).tags(EndpointTag.of("fips")).build(),
                    "waf-regional-fips.ap-southeast-2.amazonaws.com")
            .put(ServiceEndpointKey.builder().region(Region.of("ap-southeast-3")).build(),
                    "waf-regional.ap-southeast-3.amazonaws.com")
            .put(ServiceEndpointKey.builder().region(Region.of("ap-southeast-3")).tags(EndpointTag.of("fips")).build(),
                    "waf-regional-fips.ap-southeast-3.amazonaws.com")
            .put(ServiceEndpointKey.builder().region(Region.of("ap-southeast-4")).build(),
                    "waf-regional.ap-southeast-4.amazonaws.com")
            .put(ServiceEndpointKey.builder().region(Region.of("ap-southeast-4")).tags(EndpointTag.of("fips")).build(),
                    "waf-regional-fips.ap-southeast-4.amazonaws.com")
            .put(ServiceEndpointKey.builder().region(Region.of("ca-central-1")).build(),
                    "waf-regional.ca-central-1.amazonaws.com")
            .put(ServiceEndpointKey.builder().region(Region.of("ca-central-1")).tags(EndpointTag.of("fips")).build(),
                    "waf-regional-fips.ca-central-1.amazonaws.com")
            .put(ServiceEndpointKey.builder().region(Region.of("eu-central-1")).build(),
                    "waf-regional.eu-central-1.amazonaws.com")
            .put(ServiceEndpointKey.builder().region(Region.of("eu-central-1")).tags(EndpointTag.of("fips")).build(),
                    "waf-regional-fips.eu-central-1.amazonaws.com")
            .put(ServiceEndpointKey.builder().region(Region.of("eu-central-2")).build(),
                    "waf-regional.eu-central-2.amazonaws.com")
            .put(ServiceEndpointKey.builder().region(Region.of("eu-central-2")).tags(EndpointTag.of("fips")).build(),
                    "waf-regional-fips.eu-central-2.amazonaws.com")
            .put(ServiceEndpointKey.builder().region(Region.of("eu-north-1")).build(), "waf-regional.eu-north-1.amazonaws.com")
            .put(ServiceEndpointKey.builder().region(Region.of("eu-north-1")).tags(EndpointTag.of("fips")).build(),
                    "waf-regional-fips.eu-north-1.amazonaws.com")
            .put(ServiceEndpointKey.builder().region(Region.of("eu-south-1")).build(), "waf-regional.eu-south-1.amazonaws.com")
            .put(ServiceEndpointKey.builder().region(Region.of("eu-south-1")).tags(EndpointTag.of("fips")).build(),
                    "waf-regional-fips.eu-south-1.amazonaws.com")
            .put(ServiceEndpointKey.builder().region(Region.of("eu-south-2")).build(), "waf-regional.eu-south-2.amazonaws.com")
            .put(ServiceEndpointKey.builder().region(Region.of("eu-south-2")).tags(EndpointTag.of("fips")).build(),
                    "waf-regional-fips.eu-south-2.amazonaws.com")
            .put(ServiceEndpointKey.builder().region(Region.of("eu-west-1")).build(), "waf-regional.eu-west-1.amazonaws.com")
            .put(ServiceEndpointKey.builder().region(Region.of("eu-west-1")).tags(EndpointTag.of("fips")).build(),
                    "waf-regional-fips.eu-west-1.amazonaws.com")
            .put(ServiceEndpointKey.builder().region(Region.of("eu-west-2")).build(), "waf-regional.eu-west-2.amazonaws.com")
            .put(ServiceEndpointKey.builder().region(Region.of("eu-west-2")).tags(EndpointTag.of("fips")).build(),
                    "waf-regional-fips.eu-west-2.amazonaws.com")
            .put(ServiceEndpointKey.builder().region(Region.of("eu-west-3")).build(), "waf-regional.eu-west-3.amazonaws.com")
            .put(ServiceEndpointKey.builder().region(Region.of("eu-west-3")).tags(EndpointTag.of("fips")).build(),
                    "waf-regional-fips.eu-west-3.amazonaws.com")
            .put(ServiceEndpointKey.builder().region(Region.of("fips-af-south-1")).build(),
                    "waf-regional-fips.af-south-1.amazonaws.com")
            .put(ServiceEndpointKey.builder().region(Region.of("fips-ap-east-1")).build(),
                    "waf-regional-fips.ap-east-1.amazonaws.com")
            .put(ServiceEndpointKey.builder().region(Region.of("fips-ap-northeast-1")).build(),
                    "waf-regional-fips.ap-northeast-1.amazonaws.com")
            .put(ServiceEndpointKey.builder().region(Region.of("fips-ap-northeast-2")).build(),
                    "waf-regional-fips.ap-northeast-2.amazonaws.com")
            .put(ServiceEndpointKey.builder().region(Region.of("fips-ap-northeast-3")).build(),
                    "waf-regional-fips.ap-northeast-3.amazonaws.com")
            .put(ServiceEndpointKey.builder().region(Region.of("fips-ap-south-1")).build(),
                    "waf-regional-fips.ap-south-1.amazonaws.com")
            .put(ServiceEndpointKey.builder().region(Region.of("fips-ap-southeast-1")).build(),
                    "waf-regional-fips.ap-southeast-1.amazonaws.com")
            .put(ServiceEndpointKey.builder().region(Region.of("fips-ap-southeast-2")).build(),
                    "waf-regional-fips.ap-southeast-2.amazonaws.com")
            .put(ServiceEndpointKey.builder().region(Region.of("fips-ca-central-1")).build(),
                    "waf-regional-fips.ca-central-1.amazonaws.com")
            .put(ServiceEndpointKey.builder().region(Region.of("fips-eu-central-1")).build(),
                    "waf-regional-fips.eu-central-1.amazonaws.com")
            .put(ServiceEndpointKey.builder().region(Region.of("fips-eu-north-1")).build(),
                    "waf-regional-fips.eu-north-1.amazonaws.com")
            .put(ServiceEndpointKey.builder().region(Region.of("fips-eu-south-1")).build(),
                    "waf-regional-fips.eu-south-1.amazonaws.com")
            .put(ServiceEndpointKey.builder().region(Region.of("fips-eu-west-1")).build(),
                    "waf-regional-fips.eu-west-1.amazonaws.com")
            .put(ServiceEndpointKey.builder().region(Region.of("fips-eu-west-2")).build(),
                    "waf-regional-fips.eu-west-2.amazonaws.com")
            .put(ServiceEndpointKey.builder().region(Region.of("fips-eu-west-3")).build(),
                    "waf-regional-fips.eu-west-3.amazonaws.com")
            .put(ServiceEndpointKey.builder().region(Region.of("fips-me-south-1")).build(),
                    "waf-regional-fips.me-south-1.amazonaws.com")
            .put(ServiceEndpointKey.builder().region(Region.of("fips-sa-east-1")).build(),
                    "waf-regional-fips.sa-east-1.amazonaws.com")
            .put(ServiceEndpointKey.builder().region(Region.of("fips-us-east-1")).build(),
                    "waf-regional-fips.us-east-1.amazonaws.com")
            .put(ServiceEndpointKey.builder().region(Region.of("fips-us-east-2")).build(),
                    "waf-regional-fips.us-east-2.amazonaws.com")
            .put(ServiceEndpointKey.builder().region(Region.of("fips-us-west-1")).build(),
                    "waf-regional-fips.us-west-1.amazonaws.com")
            .put(ServiceEndpointKey.builder().region(Region.of("fips-us-west-2")).build(),
                    "waf-regional-fips.us-west-2.amazonaws.com")
            .put(ServiceEndpointKey.builder().region(Region.of("me-central-1")).build(),
                    "waf-regional.me-central-1.amazonaws.com")
            .put(ServiceEndpointKey.builder().region(Region.of("me-central-1")).tags(EndpointTag.of("fips")).build(),
                    "waf-regional-fips.me-central-1.amazonaws.com")
            .put(ServiceEndpointKey.builder().region(Region.of("me-south-1")).build(), "waf-regional.me-south-1.amazonaws.com")
            .put(ServiceEndpointKey.builder().region(Region.of("me-south-1")).tags(EndpointTag.of("fips")).build(),
                    "waf-regional-fips.me-south-1.amazonaws.com")
            .put(ServiceEndpointKey.builder().region(Region.of("sa-east-1")).build(), "waf-regional.sa-east-1.amazonaws.com")
            .put(ServiceEndpointKey.builder().region(Region.of("sa-east-1")).tags(EndpointTag.of("fips")).build(),
                    "waf-regional-fips.sa-east-1.amazonaws.com")
            .put(ServiceEndpointKey.builder().region(Region.of("us-east-1")).build(), "waf-regional.us-east-1.amazonaws.com")
            .put(ServiceEndpointKey.builder().region(Region.of("us-east-1")).tags(EndpointTag.of("fips")).build(),
                    "waf-regional-fips.us-east-1.amazonaws.com")
            .put(ServiceEndpointKey.builder().region(Region.of("us-east-2")).build(), "waf-regional.us-east-2.amazonaws.com")
            .put(ServiceEndpointKey.builder().region(Region.of("us-east-2")).tags(EndpointTag.of("fips")).build(),
                    "waf-regional-fips.us-east-2.amazonaws.com")
            .put(ServiceEndpointKey.builder().region(Region.of("us-west-1")).build(), "waf-regional.us-west-1.amazonaws.com")
            .put(ServiceEndpointKey.builder().region(Region.of("us-west-1")).tags(EndpointTag.of("fips")).build(),
                    "waf-regional-fips.us-west-1.amazonaws.com")
            .put(ServiceEndpointKey.builder().region(Region.of("us-west-2")).build(), "waf-regional.us-west-2.amazonaws.com")
            .put(ServiceEndpointKey.builder().region(Region.of("us-west-2")).tags(EndpointTag.of("fips")).build(),
                    "waf-regional-fips.us-west-2.amazonaws.com")
            .put(ServiceEndpointKey.builder().region(Region.of("cn-north-1")).build(), "waf-regional.cn-north-1.amazonaws.com.cn")
            .put(ServiceEndpointKey.builder().region(Region.of("cn-north-1")).tags(EndpointTag.of("fips")).build(),
                    "waf-regional-fips.cn-north-1.amazonaws.com.cn")
            .put(ServiceEndpointKey.builder().region(Region.of("cn-northwest-1")).build(),
                    "waf-regional.cn-northwest-1.amazonaws.com.cn")
            .put(ServiceEndpointKey.builder().region(Region.of("cn-northwest-1")).tags(EndpointTag.of("fips")).build(),
                    "waf-regional-fips.cn-northwest-1.amazonaws.com.cn")
            .put(ServiceEndpointKey.builder().region(Region.of("fips-cn-north-1")).build(),
                    "waf-regional-fips.cn-north-1.amazonaws.com.cn")
            .put(ServiceEndpointKey.builder().region(Region.of("fips-cn-northwest-1")).build(),
                    "waf-regional-fips.cn-northwest-1.amazonaws.com.cn")
            .put(ServiceEndpointKey.builder().region(Region.of("fips-us-gov-east-1")).build(),
                    "waf-regional-fips.us-gov-east-1.amazonaws.com")
            .put(ServiceEndpointKey.builder().region(Region.of("fips-us-gov-west-1")).build(),
                    "waf-regional-fips.us-gov-west-1.amazonaws.com")
            .put(ServiceEndpointKey.builder().region(Region.of("us-gov-east-1")).build(),
                    "waf-regional.us-gov-east-1.amazonaws.com")
            .put(ServiceEndpointKey.builder().region(Region.of("us-gov-east-1")).tags(EndpointTag.of("fips")).build(),
                    "waf-regional-fips.us-gov-east-1.amazonaws.com")
            .put(ServiceEndpointKey.builder().region(Region.of("us-gov-west-1")).build(),
                    "waf-regional.us-gov-west-1.amazonaws.com")
            .put(ServiceEndpointKey.builder().region(Region.of("us-gov-west-1")).tags(EndpointTag.of("fips")).build(),
                    "waf-regional-fips.us-gov-west-1.amazonaws.com").build();

    private static final Map<Pair<String, PartitionEndpointKey>, String> HOSTNAMES_BY_PARTITION = ImmutableMap
            .<Pair<String, PartitionEndpointKey>, String> builder().build();

    @Override
    public List<Region> regions() {
        return REGIONS;
    }

    @Override
    public List<ServicePartitionMetadata> servicePartitions() {
        return PARTITIONS;
    }

    @Override
    public URI endpointFor(ServiceEndpointKey key) {
        return ServiceMetadataUtils.endpointFor(ServiceMetadataUtils.hostname(key, HOSTNAMES_BY_REGION, HOSTNAMES_BY_PARTITION),
                ENDPOINT_PREFIX, key.region().id(),
                ServiceMetadataUtils.dnsSuffix(key, DNS_SUFFIXES_BY_REGION, DNS_SUFFIXES_BY_PARTITION));
    }

    @Override
    public Region signingRegion(ServiceEndpointKey key) {
        return ServiceMetadataUtils.signingRegion(key, SIGNING_REGIONS_BY_REGION, SIGNING_REGIONS_BY_PARTITION);
    }
}
